package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Arcana Noctis", appName)
  }

  @Test
  fun `tarot deck contains exactly 78 cards without duplicates`() {
    val cards = com.example.data.TarotRepository.allCards
    assertEquals(78, cards.size)
    val uniqueIds = cards.map { it.id }.toSet()
    assertEquals(78, uniqueIds.size)
  }
}

package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "readings")
data class ReadingEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long,
    val formattedDate: String,
    val spreadId: String,
    val spreadName: String,
    val userName: String,
    val question: String,
    val backstory: String,
    val customTitle: String,
    val personalNotes: String,
    val isFavorite: Boolean = false,
    val cardIds: String, // comma separated card IDs
    val cardReversals: String, // comma separated boolean (true/false)
    val executiveSummary: String,
    val dominantEnergy: String,
    val fullSynthesis: String
)

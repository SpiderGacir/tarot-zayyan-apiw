package com.example.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CardInterpretation(
    val card: TarotCard,
    val isReversed: Boolean,
    val position: SpreadPosition,
    val specificMeaning: String,
    val detailedAnalysis: String,
    val shadowWarning: String,
    val reflectionPrompt: String
)

data class ReadingResult(
    val id: String = System.currentTimeMillis().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val formattedDate: String,
    val spreadType: SpreadType,
    val userName: String,
    val userQuestion: String,
    val userBackstory: String,
    val title: String,
    val executiveSummary: String,
    val cardInterpretations: List<CardInterpretation>,
    val dominantEnergy: String,
    val crossCardSynthesis: String,
    val tensionsAndConflicts: String,
    val realisticScenarios: String,
    val blindSpotsToWatch: String,
    val actionableAdvice: List<String>,
    val journalingPrompts: List<String>,
    val closingSynthesis: String,
    val ethicalDisclaimer: String
)

object TarotInterpretationEngine {

    fun generateResult(
        spreadType: SpreadType,
        drawnCards: List<Pair<TarotCard, Boolean>>,
        userName: String,
        userQuestion: String,
        userBackstory: String,
        isEn: Boolean = false
    ): ReadingResult {
        val dateFormat = SimpleDateFormat("EEEE, d MMMM yyyy HH:mm", if (isEn) Locale.ENGLISH else Locale("id", "ID"))
        val formattedDate = dateFormat.format(Date())

        val cleanName = userName.trim().ifEmpty { if (isEn) "Seeker" else "Sahabat" }
        val cleanQuestion = userQuestion.trim().ifEmpty {
            if (isEn) "General Reflection & Clarity" else "Refleksi Batin & Arah Hidup"
        }

        // Map each drawn card to its spread position
        val interpretations = drawnCards.mapIndexed { index, (card, isReversed) ->
            val position = spreadType.positions.getOrNull(index) ?: SpreadPosition(
                index = index,
                titleId = "Posisi ${index + 1}",
                titleEn = "Position ${index + 1}",
                descriptionId = "Pengaruh dan simbolisme kartu.",
                descriptionEn = "Card influence and symbolism."
            )

            val baseMeaning = when {
                spreadType.category == SpreadCategory.LOVE -> if (isReversed) {
                    if (isEn) "${card.reversedEn} In relationships: ${card.loveEn}"
                    else "${card.reversedId} Dalam hubungan: ${card.loveId}"
                } else {
                    if (isEn) "${card.uprightEn} In relationships: ${card.loveEn}"
                    else "${card.uprightId} Dalam hubungan: ${card.loveId}"
                }
                spreadType.category == SpreadCategory.CAREER -> if (isReversed) {
                    if (isEn) "${card.reversedEn} Professionally: ${card.careerEn}"
                    else "${card.reversedId} Dalam karier: ${card.careerId}"
                } else {
                    if (isEn) "${card.uprightEn} Professionally: ${card.careerEn}"
                    else "${card.uprightId} Dalam karier: ${card.careerId}"
                }
                spreadType.category == SpreadCategory.SELF -> if (isReversed) {
                    if (isEn) "${card.reversedEn} For self-discovery: ${card.selfEn}"
                    else "${card.reversedId} Untuk batin: ${card.selfId}"
                } else {
                    if (isEn) "${card.uprightEn} For self-discovery: ${card.selfEn}"
                    else "${card.uprightId} Untuk batin: ${card.selfId}"
                }
                else -> if (isReversed) {
                    if (isEn) card.reversedEn else card.reversedId
                } else {
                    if (isEn) card.uprightEn else card.uprightId
                }
            }

            val posTitle = if (isEn) position.titleEn else position.titleId
            val cardName = if (isEn) card.nameEn else card.nameId
            val orientBadge = if (isReversed) {
                if (isEn) "(Reversed / Inverted)" else "(Terbalik / Reversed)"
            } else {
                if (isEn) "(Upright)" else "(Tegak / Upright)"
            }

            val detailed = if (isEn) {
                "In the position of '$posTitle', $cardName $orientBadge acts as a mirror to your current chapter. Rather than a rigid decree, this card highlights ${card.keywordsEn}. The energy here suggests that ${baseMeaning.lowercase()}"
            } else {
                "Pada posisi '$posTitle', kartu $cardName $orientBadge hadir sebagai cermin bagi prosesmu saat ini. Melalui simbol ${card.keywordsId}, kartu ini menekankan bahwa ${baseMeaning.lowercase()}"
            }

            val shadow = if (isEn) card.shadowEn else card.shadowId
            val prompt = if (isEn) card.reflectionEn else card.reflectionId

            CardInterpretation(
                card = card,
                isReversed = isReversed,
                position = position,
                specificMeaning = baseMeaning,
                detailedAnalysis = detailed,
                shadowWarning = shadow,
                reflectionPrompt = prompt
            )
        }

        // Elemental and Arcana balance
        val majorCount = drawnCards.count { it.first.arcana == ArcanaType.MAJOR }
        val wandsCount = drawnCards.count { it.first.suit == TarotSuit.WANDS }
        val cupsCount = drawnCards.count { it.first.suit == TarotSuit.CUPS }
        val swordsCount = drawnCards.count { it.first.suit == TarotSuit.SWORDS }
        val pentaclesCount = drawnCards.count { it.first.suit == TarotSuit.PENTACLES }
        val reversedCount = drawnCards.count { it.second }

        val dominantElement = when {
            majorCount >= (drawnCards.size / 2).coerceAtLeast(2) -> if (isEn) "Spiritual Destiny & Major Life Shift (Major Arcana Dominant)" else "Takdir Jiwa & Transformasi Besar (Major Arcana Dominan)"
            cupsCount >= (drawnCards.size / 3).coerceAtLeast(2) -> if (isEn) "Water Element (Emotion, Intuition & Relationships)" else "Elemen Air (Emosi, Hubungan & Kedalaman Hati)"
            swordsCount >= (drawnCards.size / 3).coerceAtLeast(2) -> if (isEn) "Air Element (Clarity, Truth & Mental Decisions)" else "Elemen Udara (Kejernihan, Keputusan & Batasan Pikiran)"
            wandsCount >= (drawnCards.size / 3).coerceAtLeast(2) -> if (isEn) "Fire Element (Passion, Ambition & Vital Drive)" else "Elemen Api (Gairah, Inisiatif & Dorongan Aksi)"
            pentaclesCount >= (drawnCards.size / 3).coerceAtLeast(2) -> if (isEn) "Earth Element (Material Stability, Body & Grounding)" else "Elemen Tanah (Stabilitas Materi, Tubuh & Realita)"
            else -> if (isEn) "Balanced Elemental Harmony" else "Keseimbangan Multidimensi"
        }

        val spreadName = if (isEn) spreadType.nameEn else spreadType.nameId
        val title = if (isEn) {
            "Noctis Reading for $cleanName: $cleanQuestion"
        } else {
            "Pembacaan Arcana untuk $cleanName: $cleanQuestion"
        }

        val primaryCard = drawnCards.first().first
        val primaryName = if (isEn) primaryCard.nameEn else primaryCard.nameId
        val executiveSummary = if (isEn) {
            "Through this $spreadName spread, the dominant archetype of $primaryName reflects a pivotal transition in your relationship with '$cleanQuestion'. The cards indicate that clarity comes not from forcing outcomes, but from aligning your honest internal boundaries with patient discernment. What was once uncertain is now ready to be understood from a higher vantage."
        } else {
            "Melalui spread $spreadName ini, arketipe utama $primaryName memperlihatkan fase transisi penting terkait '$cleanQuestion'. Simbol-simbol yang muncul menunjukkan bahwa kejelasan tidak lahir dari memaksakan kehendak, melainkan dari keberanian menyelaraskan nurani batin dengan kesabaran memproses kenyataan. Sesuatu yang sebelumnya terasa mengganjal kini siap dipahami dari sudut pandang yang lebih luas dan dewasa."
        }

        val crossCardSynthesis = if (isEn) {
            "From the ${drawnCards.size} cards drawn, there is a prominent resonance between the initial anchor (${interpretations.first().card.nameEn}) and the unfolding direction (${interpretations.last().card.nameEn}). With $majorCount Major Arcana cards active, this indicates a deeply meaningful life lesson rather than passing trivial circumstances. The presence of $reversedCount inverted energies suggests an internal recalibration—changes that must mature within you before becoming visible to the outside world."
        } else {
            "Dari ${drawnCards.size} kartu yang ditarik, terlihat dialog yang kuat antara kartu pembuka (${interpretations.first().card.nameId}) dengan arah resolusi pada kartu penutup (${interpretations.last().card.nameId}). Kehadiran $majorCount kartu Major Arcana menandakan bahwa fase ini menyentuh pembelajaran jiwa yang esensial, bukan sekadar riak masalah sepele. Sebanyak $reversedCount kartu terbalik mengisyaratkan proses perenungan internal—sesuatu yang perlu kamu tata rapi di dalam hati sebelum diproyeksikan keluar."
        }

        val tensionsAndConflicts = if (swordsCount > 0 && cupsCount > 0) {
            if (isEn) {
                "There is an active dialogue between the sharp intellect of Swords and the tender currents of Cups. Your rational mind desires immediate logical closure, while your emotional heart still needs gentle space to feel and accept. Avoid judging yourself for feeling vulnerable while trying to remain strong."
            } else {
                "Terlihat dinamika kontras antara ketajaman logika Pedang (Swords) dan kelembutan perasaan Piala (Cups). Pikiran rasionalmu ingin segera menemukan jawaban logis yang tegas, sementara hatimu masih membutuhkan waktu untuk memproses rasa. Jangan menghukum dirimu sendiri karena merasa rapuh di saat kamu sedang berusaha menjadi sosok yang kuat."
            }
        } else if (wandsCount > 0 && pentaclesCount > 0) {
            if (isEn) {
                "A creative tension exists between the fiery urge of Wands to charge forward and the patient discipline of Pentacles demanding steady preparation. Balance ambition with daily pacing."
            } else {
                "Terdapat ketegangan dinamis antara dorongan api Tongkat (Wands) yang ingin lekas melaju dengan ketenangan Koin (Pentacles) yang menuntut fondasi matang. Seimbangkan antusiasme dengan ritme kerja yang berkelanjutan."
            }
        } else {
            if (isEn) {
                "The primary tension lies between your past familiarity and the unfamiliar courage required to step into the next threshold. Watch for subtle resistance masquerading as hesitation."
            } else {
                "Ketegangan utama berpusat pada kenyamanan pola lama yang sudah kamu kenal berhadapan dengan keberanian melangkah ke ruang baru. Waspadai keraguan yang menyamar sebagai alasan menunda-nunda."
            }
        }

        val realisticScenarios = if (spreadType.category == SpreadCategory.LOVE) {
            if (isEn) {
                "Symbolic tendencies (not rigid predictions): 1) If communication was strained, clarity emerges best through gentle, unhurried boundary setting rather than reactive demands. 2) The connection asks you to reclaim your emotional sovereignty first; only when you feel whole within yourself can any relational dynamic find honest peace or graceful closure."
            } else {
                "Kecenderungan simbolik (bukan kepastian absolut): 1) Jika ada komunikasi yang tersendat, kejelasan paling mungkin terbuka melalui komunikasi yang tenang dan tidak menuntut secara reaktif. 2) Dinamika ini menuntutmu untuk memulihkan keutuhan dirimu sendiri terlebih dahulu; ketika kamu tidak lagi bergantung pada kepastian orang lain demi merasa berharga, keputusan terbaik akan tampak dengan sendirinya."
            }
        } else {
            if (isEn) {
                "Emerging possibilities: 1) A steady breakthrough is likely as you simplify redundant commitments and focus on one core priority. 2) Expect an invitation to refine your approach—stepping away from defensive habits opens new collaborative doors."
            } else {
                "Kemungkinan yang terbuka: 1) Kemajuan nyata akan terasa saat kamu memangkas hal-hal yang menguras tenaga dan memusatkan energi pada satu prioritas esensial. 2) Kesempatan baru akan menyambutmu saat kamu mengganti sikap bertahan dengan keterbukaan untuk belajar cara baru."
            }
        }

        val blindSpots = if (isEn) {
            "Blind spot: Be mindful of assuming you know the outcome before it unfolds. Also beware of confusing temporary discomfort with permanent failure."
        } else {
            "Hal yang perlu diperhatikan: Waspadai kecenderungan mengasumsikan akhir cerita sebelum prosesnya benar-benar tuntas. Jangan menyamakan rasa tidak nyaman sesaat dengan kegagalan permanen."
        }

        val adviceList = if (isEn) {
            listOf(
                "Pause before reacting to sudden triggers; give your nervous system 24 hours of grace.",
                "Assert one clear, non-negotiable boundary that honors your mental peace.",
                "Take one small, tangible action today toward what brings you authentic joy, without needing external validation."
            )
        } else {
            listOf(
                "Beri jeda sebelum merespons pemicu emosi; beri tubuh dan pikiranmu waktu istirahat yang cukup.",
                "Tegakkan satu batasan sehat yang melindungi energimu dari rasa lelah yang tidak perlu.",
                "Ambil satu langkah kecil dan konkret hari ini untuk merawat tujuan hidupmu, tanpa perlu menuntut pengakuan orang lain."
            )
        }

        val journaling = interpretations.take(3).map { it.reflectionPrompt }

        val closing = if (isEn) {
            "Arcana Noctis reminds you: The cards are mirrors, not chains. The future is not etched in stone; it responds to the consciousness and sovereignty you bring to each present choice. Honor your journey."
        } else {
            "Arcana Noctis mengingatkan: Simbol tarot adalah cermin refleksi, bukan rantai takdir yang mengikat. Masa depan tidak dipahat di atas batu beku; ia merespons kedewasaan nurani dan pilihan sadar yang kamu ambil di saat ini. Hormati dan cintai perjalananmu."
        }

        val disclaimer = if (isEn) {
            "Tarot is a symbolic framework for psychological self-discovery, intuition, and introspection. It does not replace professional medical, legal, psychological, or financial counsel, nor does it claim absolute determinism."
        } else {
            "Tarot adalah sarana simbolik untuk refleksi batin, mengasah intuisi, dan menjelajahi perspektif psikologis. Tarot bukan ramalan mutlak, bukan pengganti nasihat medis, hukum, psikologis, atau finansial profesional, dan tidak mengklaim kepastian masa depan."
        }

        return ReadingResult(
            formattedDate = formattedDate,
            spreadType = spreadType,
            userName = cleanName,
            userQuestion = cleanQuestion,
            userBackstory = userBackstory,
            title = title,
            executiveSummary = executiveSummary,
            cardInterpretations = interpretations,
            dominantEnergy = dominantElement,
            crossCardSynthesis = crossCardSynthesis,
            tensionsAndConflicts = tensionsAndConflicts,
            realisticScenarios = realisticScenarios,
            blindSpotsToWatch = blindSpots,
            actionableAdvice = adviceList,
            journalingPrompts = journaling,
            closingSynthesis = closing,
            ethicalDisclaimer = disclaimer
        )
    }
}

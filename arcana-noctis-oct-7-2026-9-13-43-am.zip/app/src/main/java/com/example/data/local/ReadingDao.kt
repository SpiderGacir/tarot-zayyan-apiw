package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ReadingDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(reading: ReadingEntity): Long

    @Update
    suspend fun update(reading: ReadingEntity)

    @Delete
    suspend fun delete(reading: ReadingEntity)

    @Query("DELETE FROM readings WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM readings")
    suspend fun clearAll()

    @Query("SELECT * FROM readings ORDER BY timestamp DESC")
    fun getAllFlow(): Flow<List<ReadingEntity>>

    @Query("SELECT * FROM readings WHERE isFavorite = 1 ORDER BY timestamp DESC")
    fun getFavoritesFlow(): Flow<List<ReadingEntity>>

    @Query("SELECT * FROM readings WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): ReadingEntity?

    @Query("""
        SELECT * FROM readings 
        WHERE customTitle LIKE '%' || :query || '%' 
           OR question LIKE '%' || :query || '%' 
           OR spreadName LIKE '%' || :query || '%'
           OR personalNotes LIKE '%' || :query || '%'
        ORDER BY timestamp DESC
    """)
    fun searchFlow(query: String): Flow<List<ReadingEntity>>
}

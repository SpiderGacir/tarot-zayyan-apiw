package com.example.data

data class SpreadPosition(
    val index: Int,
    val titleId: String,
    val titleEn: String,
    val descriptionId: String,
    val descriptionEn: String
)

enum class SpreadCategory(val titleId: String, val titleEn: String, val icon: String) {
    GENERAL("Umum & Harian", "General & Daily", "✦"),
    LOVE("Cinta & Hubungan", "Love & Relationship", "♥"),
    CAREER("Karier & Finansial", "Career & Wealth", "◆"),
    SELF("Refleksi Diri", "Self Discovery", "☼"),
    CUSTOM("Custom Spread", "Custom Spread", "⚙")
}

data class SpreadType(
    val id: String,
    val nameId: String,
    val nameEn: String,
    val descriptionId: String,
    val descriptionEn: String,
    val cardCount: Int,
    val category: SpreadCategory,
    val positions: List<SpreadPosition>
)

object SpreadsData {
    val oneCard = SpreadType(
        id = "one_card",
        nameId = "Satu Kartu (Refleksi Harian)",
        nameEn = "One Card (Daily Reflection)",
        descriptionId = "Satu kartu untuk memfokuskan energi hari ini, mencari perspektif baru, atau menjawab pertanyaan sederhana.",
        descriptionEn = "A single card for daily grounding, a fresh perspective, or focused contemplation.",
        cardCount = 1,
        category = SpreadCategory.GENERAL,
        positions = listOf(
            SpreadPosition(0, "Tema Inti Hari Ini", "Core Insight of the Day", "Simbol utama yang membimbing fokus dan energimu saat ini.", "The central archetype guiding your focus today.")
        )
    )

    val threePastPresentFuture = SpreadType(
        id = "three_ppf",
        nameId = "Tiga Kartu: Garis Waktu",
        nameEn = "Three Cards: Timeline",
        descriptionId = "Menjelajahi kontinuitas perjalanan dari akar masa lalu, titik saat ini, hingga kecenderungan masa depan.",
        descriptionEn = "Exploring continuity from past roots, current standing, to emerging trajectories.",
        cardCount = 3,
        category = SpreadCategory.GENERAL,
        positions = listOf(
            SpreadPosition(0, "Masa Lalu (Akar)", "Past (Roots)", "Pengalaman atau fondasi yang membentuk situasi saat ini.", "Formative experiences anchoring current conditions."),
            SpreadPosition(1, "Masa Kini (Kenyataan)", "Present (Current State)", "Kondisi energimu dan fokus utamamu hari ini.", "Your current energetic center and immediate reality."),
            SpreadPosition(2, "Masa Depan (Kecenderungan)", "Future (Trajectory)", "Arah perkembangan jika ritme saat ini terus berlanjut.", "Emerging potential if current trajectory continues.")
        )
    )

    val threeSituationChallengeAdvice = SpreadType(
        id = "three_sca",
        nameId = "Tiga Kartu: Situasi, Tantangan & Saran",
        nameEn = "Three Cards: Situation, Challenge & Advice",
        descriptionId = "Kerangka paling efektif untuk memecahkan dilema dan menemukan langkah konstruktif.",
        descriptionEn = "Action-oriented framework for navigating obstacles with wisdom.",
        cardCount = 3,
        category = SpreadCategory.GENERAL,
        positions = listOf(
            SpreadPosition(0, "Situasi Nyata", "Situation", "Konteks keadaan apa adanya tanpa distorsi.", "The objective landscape of your dilemma."),
            SpreadPosition(1, "Tantangan Utama", "Challenge", "Hambatan atau titik gesekan yang perlu kamu hadapi.", "The primary friction or hidden hurdle testing you."),
            SpreadPosition(2, "Saran Konstruktif", "Advice", "Langkah nyata dan sikap batin yang paling bijak.", "The most empowering posture or constructive action.")
        )
    )

    val threeMindHeartAction = SpreadType(
        id = "three_mha",
        nameId = "Tiga Kartu: Pikiran, Hati & Tindakan",
        nameEn = "Three Cards: Mind, Heart & Action",
        descriptionId = "Menyelaraskan rasionalitas akal, kedalaman emosi, dan wujud tindakan nyata.",
        descriptionEn = "Aligning rational discernment, emotional depth, and tangible expression.",
        cardCount = 3,
        category = SpreadCategory.SELF,
        positions = listOf(
            SpreadPosition(0, "Pikiran (Logika)", "Mind (Logic)", "Apa yang dipikirkan dan dianalisis oleh akalmu.", "Your conscious thoughts and intellectual frameworks."),
            SpreadPosition(1, "Hati (Emosi)", "Heart (Emotion)", "Apa yang dirasakan dan dirindukan oleh jiwamu.", "Your authentic feelings and unspoken longings."),
            SpreadPosition(2, "Tindakan (Wujud)", "Action (Expression)", "Langkah jembatan yang menyatukan akal dan rasa.", "The integrated physical action that bridges both.")
        )
    )

    val threeReleaseUnderstandEmbrace = SpreadType(
        id = "three_rue",
        nameId = "Tiga Kartu: Lepaskan, Pahami & Rangkul",
        nameEn = "Three Cards: Release, Understand & Embrace",
        descriptionId = "Ritual transisi batin untuk membersihkan beban lama dan menyambut fase baru.",
        descriptionEn = "Soul clearing spread to let go of old baggage and welcome renewal.",
        cardCount = 3,
        category = SpreadCategory.SELF,
        positions = listOf(
            SpreadPosition(0, "Hal yang Perlu Dilepaskan", "What to Release", "Pola atau beban lama yang sudah tidak lagi berguna.", "Habits or attachments that have completed their cycle."),
            SpreadPosition(1, "Hal yang Perlu Dipahami", "What to Understand", "Pelajaran berharga di balik proses yang kamu lalui.", "The core lesson concealed beneath recent trials."),
            SpreadPosition(2, "Hal yang Perlu Dirangkul", "What to Embrace", "Kualitas baru yang siap kamu sambut dengan tangan terbuka.", "The fresh archetype ready to be integrated into your life.")
        )
    )

    val loveRelationship = SpreadType(
        id = "love_5",
        nameId = "Dinamika Cinta & Relasi",
        nameEn = "Love & Relationship Spread",
        descriptionId = "Spread 5 kartu mendalam untuk memetakan dinamika hubungan, kebutuhan diri, dan langkah harmonis ke depan.",
        descriptionEn = "5-card relational mapping examining personal needs, mutual dynamics, and healthy steps.",
        cardCount = 5,
        category = SpreadCategory.LOVE,
        positions = listOf(
            SpreadPosition(0, "Kebutuhan & Perasaan Diri", "Your Feelings & Needs", "Kondisi hatimu dan apa yang sebenarnya kamu butuhkan dalam cinta.", "Your internal emotional posture and relational needs."),
            SpreadPosition(1, "Dinamika Hubungan", "Relationship Dynamic", "Interaksi nyata dan energi bersama yang sedang berlangsung.", "The shared energetic climate between both of you."),
            SpreadPosition(2, "Tantangan Utama", "Core Challenge", "Akar perselisihan, ekspektasi tersembunyi, atau ketakutan.", "The friction point or boundary issue needing attention."),
            SpreadPosition(3, "Hal yang Perlu Dipahami", "What to Understand", "Perspektif yang lebih luas tentang pembelajaran hubungan ini.", "The deeper soul lesson beneath the romantic tension."),
            SpreadPosition(4, "Langkah Sehat ke Depan", "Healthy Path Forward", "Tindakan penuh kedewasaan untuk merawat atau memperjelas ikatan.", "The most mature and respectful course of action.")
        )
    )

    val unfinishedConnection = SpreadType(
        id = "unfinished_10",
        nameId = "The Unfinished Connection (10 Kartu)",
        nameEn = "The Unfinished Connection (10 Cards)",
        descriptionId = "Spread komprehensif 10 kartu untuk hubungan yang belum tuntas, situasi ambigu (situationship), atau mencari kejelasan batin.",
        descriptionEn = "Deep 10-card exploration for unresolved ties, ambiguous bonds, and finding personal closure.",
        cardCount = 10,
        category = SpreadCategory.LOVE,
        positions = listOf(
            SpreadPosition(0, "Kondisi Emosional Dirimu", "Your Emotional State", "Di mana titik batinmu berdiri saat ini.", "Where your heart truly resides right now."),
            SpreadPosition(1, "Dinamika Saat Ini", "Current Dynamic", "Keadaan relasi apa adanya di dunia nyata.", "The objective reality of the connection."),
            SpreadPosition(2, "Akar Keterikatan", "Root of Attachment", "Mengapa ikatan ini terasa begitu sulit dilupakan.", "The underlying psychological or karmic anchor."),
            SpreadPosition(3, "Hal Belum Selesai dalam Diri", "Unresolved Inner Work", "Luka atau harapan pribadi yang belum kamu tuntaskan sendiri.", "Unintegrated longings you project onto this bond."),
            SpreadPosition(4, "Perspektif Pihak Lain (Simbolik)", "Their Likely Perspective (Symbolic)", "Interpretasi simbolik tentang energi dan beban yang mungkin dipikulnya.", "Symbolic resonance of their stance without claiming mind-reading."),
            SpreadPosition(5, "Pola Komunikasi yang Tampak", "Communication Pattern", "Bagaimana dialog terjalin atau terputus selama ini.", "How words and silences have manifested between you."),
            SpreadPosition(6, "Potensi Terbukanya Komunikasi", "Potential for Reopening", "Apakah ada ruang untuk dialog yang sehat dan jujur.", "Whether an opening for grounded dialogue exists."),
            SpreadPosition(7, "Tantangan Utama / Arah Hubungan", "Core Obstacle & Direction", "Realitas rintangan yang harus dihadapi bersama.", "The stubborn friction or divergent life path."),
            SpreadPosition(8, "Hal yang Perlu Dilepaskan / Diterima", "What to Release or Accept", "Kenyataan yang harus diikhlaskan tanpa penyesalan.", "The hard truth to accept for sovereign peace."),
            SpreadPosition(9, "Langkah Terbaik ke Depan", "Best Path Forward", "Tindakan mandiri untuk menjaga martabat dan ketenangan hatimu.", "The most empowering step to restore your wholeness.")
        )
    )

    val careerMoney = SpreadType(
        id = "career_5",
        nameId = "Karier, Keuangan & Arah Usaha",
        nameEn = "Career & Financial Direction",
        descriptionId = "Spread 5 kartu untuk menavigasi keputusan profesional, hambatan, peluang, dan langkah strategis.",
        descriptionEn = "5-card strategic layout analyzing vocational opportunities, blocks, and next steps.",
        cardCount = 5,
        category = SpreadCategory.CAREER,
        positions = listOf(
            SpreadPosition(0, "Situasi Profesional Saat Ini", "Current Career Standing", "Posisi dan kapasitasmu dalam bidang pekerjaan saat ini.", "Where your professional momentum currently rests."),
            SpreadPosition(1, "Kekuatan & Aset Utamamu", "Core Strength & Asset", "Bakat atau sumber daya yang paling berharga untuk dimanfaatkan.", "Your greatest leverage or developed expertise."),
            SpreadPosition(2, "Hambatan yang Dihadapi", "The Real Obstacle", "Keterbatasan internal atau friksi eksternal yang menghalangi.", "The bottleneck or blind spot stalling progress."),
            SpreadPosition(3, "Peluang yang Patut Dipertimbangkan", "Opportunity to Consider", "Pintu atau opsi yang menjanjikan jika kamu melangkah.", "A viable avenue or perspective worth exploring."),
            SpreadPosition(4, "Langkah Nyata Berikutnya", "Next Concrete Move", "Tindakan terukur untuk mencapai kemajuan yang stabil.", "The practical action step to execute with discipline.")
        )
    )

    val selfDiscovery = SpreadType(
        id = "self_5",
        nameId = "Pencarian Jati Diri & Jiwa",
        nameEn = "Self-Discovery & Wholeness",
        descriptionId = "Spread 5 kartu untuk menyelami kebutuhan emosional, potensi tersembunyi, dan penyembuhan pribadi.",
        descriptionEn = "5-card psychological journey mapping inner needs, shadow patterns, and authentic gifts.",
        cardCount = 5,
        category = SpreadCategory.SELF,
        positions = listOf(
            SpreadPosition(0, "Kebutuhan Emosional Terdalam", "Deepest Emotional Need", "Apa yang saat ini paling dirindukan oleh jiwamu.", "What your inner child or soul is urgently calling for."),
            SpreadPosition(1, "Kekuatan Pribadi Terpendam", "Latent Inner Strength", "Ketangguhanmu yang sering kamu ragukan atau lupakan.", "An unacknowledged reservoir of courage within you."),
            SpreadPosition(2, "Pola yang Perlu Diwaspadai", "Pattern to Notice", "Kebiasaan bawah sadar yang berulang dan membatasi.", "A recurring cognitive or behavioral loop that hinders you."),
            SpreadPosition(3, "Potensi Perkembangan Jiwa", "Growth Potential", "Siapa sosok dirimu yang sedang bertunas dan mekar.", "The emerging version of yourself ready to take shape."),
            SpreadPosition(4, "Tindakan Kecil Bermakna", "Small Meaningful Action", "Satu langkah harian sederhana untuk merawat pertumbuhanmu.", "A gentle, daily ritual to anchor this awareness.")
        )
    )

    val allSpreads = listOf(
        oneCard,
        threePastPresentFuture,
        threeSituationChallengeAdvice,
        threeMindHeartAction,
        threeReleaseUnderstandEmbrace,
        loveRelationship,
        unfinishedConnection,
        careerMoney,
        selfDiscovery
    )

    fun getById(id: String): SpreadType? = allSpreads.find { it.id == id }

    fun createCustomSpread(cardCount: Int, customTitles: List<String>, isEn: Boolean): SpreadType {
        val safeCount = cardCount.coerceIn(1, 12)
        val positions = (0 until safeCount).map { idx ->
            val title = customTitles.getOrNull(idx)?.ifBlank { null }
                ?: if (isEn) "Card Position ${idx + 1}" else "Posisi Kartu ${idx + 1}"
            SpreadPosition(
                index = idx,
                titleId = title,
                titleEn = title,
                descriptionId = "Refleksi mendalam untuk kartu ke-${idx + 1}.",
                descriptionEn = "In-depth reflection for card position ${idx + 1}."
            )
        }
        return SpreadType(
            id = "custom_$safeCount",
            nameId = "Custom Spread ($safeCount Kartu)",
            nameEn = "Custom Spread ($safeCount Cards)",
            descriptionId = "Spread yang dirancang sesuai kebutuhan dan pertanyaan pribadimu.",
            descriptionEn = "A tailored spread mapped directly to your bespoke inquiry.",
            cardCount = safeCount,
            category = SpreadCategory.CUSTOM,
            positions = positions
        )
    }
}

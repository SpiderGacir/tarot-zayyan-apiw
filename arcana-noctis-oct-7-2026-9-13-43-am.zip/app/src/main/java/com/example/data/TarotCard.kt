package com.example.data

enum class ArcanaType(val titleId: String, val titleEn: String) {
    MAJOR("Major Arcana", "Major Arcana"),
    MINOR("Minor Arcana", "Minor Arcana")
}

enum class TarotSuit(val titleId: String, val titleEn: String, val elementId: String, val elementEn: String) {
    NONE("Netral", "Neutral", "Roh / Aether", "Spirit / Aether"),
    WANDS("Tongkat", "Wands", "Api", "Fire"),
    CUPS("Piala", "Cups", "Air", "Water"),
    SWORDS("Pedang", "Swords", "Udara", "Air"),
    PENTACLES("Koin", "Pentacles", "Tanah", "Earth")
}

data class TarotCard(
    val id: String,
    val nameEn: String,
    val nameId: String,
    val arcana: ArcanaType,
    val suit: TarotSuit,
    val number: String,
    val keywordsId: String,
    val keywordsEn: String,
    val uprightId: String,
    val uprightEn: String,
    val reversedId: String,
    val reversedEn: String,
    val loveId: String,
    val loveEn: String,
    val selfId: String,
    val selfEn: String,
    val careerId: String,
    val careerEn: String,
    val shadowId: String,
    val shadowEn: String,
    val reflectionId: String,
    val reflectionEn: String,
    val visualDescId: String,
    val visualDescEn: String,
    val element: String,
    val astrologySymbol: String,
    val iconSymbol: String = "✦"
)

package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class UserPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("arcana_noctis_prefs", Context.MODE_PRIVATE)

    private val _isEnglish = MutableStateFlow(prefs.getString("app_language", "id") == "en")
    val isEnglish: StateFlow<Boolean> = _isEnglish.asStateFlow()

    private val _allowReversals = MutableStateFlow(prefs.getBoolean("allow_reversals", true))
    val allowReversals: StateFlow<Boolean> = _allowReversals.asStateFlow()

    private val _enableHaptics = MutableStateFlow(prefs.getBoolean("enable_haptics", true))
    val enableHaptics: StateFlow<Boolean> = _enableHaptics.asStateFlow()

    private val _reducedMotion = MutableStateFlow(prefs.getBoolean("reduced_motion", false))
    val reducedMotion: StateFlow<Boolean> = _reducedMotion.asStateFlow()

    fun setLanguage(isEn: Boolean) {
        prefs.edit().putString("app_language", if (isEn) "en" else "id").apply()
        _isEnglish.value = isEn
    }

    fun setAllowReversals(allow: Boolean) {
        prefs.edit().putBoolean("allow_reversals", allow).apply()
        _allowReversals.value = allow
    }

    fun setEnableHaptics(enable: Boolean) {
        prefs.edit().putBoolean("enable_haptics", enable).apply()
        _enableHaptics.value = enable
    }

    fun setReducedMotion(reduce: Boolean) {
        prefs.edit().putBoolean("reduced_motion", reduce).apply()
        _reducedMotion.value = reduce
    }
}

package com.example.data

import kotlin.random.Random

object TarotRepository {
    val allCards: List<TarotCard> by lazy {
        MajorArcanaData.cards + WandsData.cards + CupsData.cards + SwordsData.cards + PentaclesData.cards
    }

    init {
        // Integrity check: exactly 78 tarot cards
        require(allCards.size == 78) { "Tarot deck must contain exactly 78 cards, found: ${allCards.size}" }
    }

    fun getCardById(id: String): TarotCard? {
        return allCards.find { it.id == id }
    }

    fun getFeaturedCards(): List<TarotCard> {
        // Three iconic cards for hero preview
        return listOfNotNull(
            getCardById("major_17"), // The Star (Hope & Healing)
            getCardById("major_1"),  // The Magician (Creation & Skill)
            getCardById("major_19")  // The Sun (Joy & Clarity)
        )
    }

    /**
     * Fisher-Yates draw without replacement.
     * Guarantees 100% unique cards in a single spread draw.
     */
    fun drawCards(
        count: Int,
        allowReversals: Boolean = true,
        reversalChance: Float = 0.35f
    ): List<Pair<TarotCard, Boolean>> {
        val safeCount = count.coerceIn(1, allCards.size)
        // Fisher-Yates shuffle of deck indices
        val shuffled = allCards.shuffled(Random.Default)
        val selected = shuffled.take(safeCount)

        return selected.map { card ->
            val isReversed = if (allowReversals) {
                Random.nextFloat() < reversalChance
            } else {
                false
            }
            card to isReversed
        }
    }

    fun filterCards(
        query: String = "",
        suit: TarotSuit? = null,
        arcana: ArcanaType? = null
    ): List<TarotCard> {
        val q = query.trim().lowercase()
        return allCards.filter { card ->
            val matchSuit = suit == null || card.suit == suit
            val matchArcana = arcana == null || card.arcana == arcana
            val matchQuery = q.isEmpty() ||
                card.nameId.lowercase().contains(q) ||
                card.nameEn.lowercase().contains(q) ||
                card.keywordsId.lowercase().contains(q) ||
                card.keywordsEn.lowercase().contains(q) ||
                card.element.lowercase().contains(q) ||
                card.astrologySymbol.lowercase().contains(q) ||
                card.number.lowercase().contains(q)

            matchSuit && matchArcana && matchQuery
        }
    }
}

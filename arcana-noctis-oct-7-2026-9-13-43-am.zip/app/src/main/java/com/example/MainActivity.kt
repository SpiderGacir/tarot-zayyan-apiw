package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ReadingResult
import com.example.data.SpreadType
import com.example.data.SpreadsData
import com.example.data.TarotCard
import com.example.data.TarotInterpretationEngine
import com.example.data.local.UserPreferences
import com.example.ui.components.ArcanaBottomNav
import com.example.ui.components.ArcanaHeader
import com.example.ui.components.ArcanaNavRoute
import com.example.ui.components.CelestialBackground
import com.example.ui.components.TarotCardView
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.JournalScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.ReadingResultScreen
import com.example.ui.screens.ReadingSelectScreen
import com.example.ui.screens.ReadingSessionScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.AntiqueGold
import com.example.ui.theme.CelestialCyan
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.LightAntiqueGold
import com.example.ui.theme.MoonSilver
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ReversalAmber

enum class ReadingFlowState {
    SELECT,
    SESSION,
    RESULT
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val userPreferences = UserPreferences(applicationContext)

        setContent {
            MyApplicationTheme {
                ArcanaNoctisApp(userPreferences = userPreferences)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArcanaNoctisApp(userPreferences: UserPreferences) {
    val isEnglish by userPreferences.isEnglish.collectAsState()
    val allowReversals by userPreferences.allowReversals.collectAsState()
    val enableHaptics by userPreferences.enableHaptics.collectAsState()
    val reducedMotion by userPreferences.reducedMotion.collectAsState()

    var currentRoute by remember { mutableStateOf(ArcanaNavRoute.HOME) }

    // Reading flow state
    var readingFlowState by remember { mutableStateOf(ReadingFlowState.SELECT) }
    var selectedSpread by remember { mutableStateOf(SpreadsData.threeSituationChallengeAdvice) }
    var currentUserName by remember { mutableStateOf("") }
    var currentUserQuestion by remember { mutableStateOf("") }
    var currentUserBackstory by remember { mutableStateOf("") }
    var currentAllowReversals by remember { mutableStateOf(allowReversals) }
    var currentReadingResult by remember { mutableStateOf<ReadingResult?>(null) }

    // Global inspect card modal (e.g. from Home preview)
    var inspectCard by remember { mutableStateOf<TarotCard?>(null) }
    var inspectCardReversed by remember { mutableStateOf(false) }

    // Handle System Back button
    BackHandler(enabled = currentRoute != ArcanaNavRoute.HOME || readingFlowState != ReadingFlowState.SELECT) {
        if (currentRoute == ArcanaNavRoute.READING) {
            when (readingFlowState) {
                ReadingFlowState.RESULT -> readingFlowState = ReadingFlowState.SELECT
                ReadingFlowState.SESSION -> readingFlowState = ReadingFlowState.SELECT
                ReadingFlowState.SELECT -> currentRoute = ArcanaNavRoute.HOME
            }
        } else {
            currentRoute = ArcanaNavRoute.HOME
        }
    }

    CelestialBackground {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                ArcanaHeader(
                    isEnglish = isEnglish,
                    onToggleLanguage = { userPreferences.setLanguage(!isEnglish) },
                    modifier = Modifier.statusBarsPadding()
                )
            },
            bottomBar = {
                ArcanaBottomNav(
                    currentRoute = currentRoute,
                    onNavigate = { route ->
                        currentRoute = route
                    },
                    isEnglish = isEnglish
                )
            },
            containerColor = androidx.compose.ui.graphics.Color.Transparent
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                AnimatedContent(
                    targetState = currentRoute,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "screen_transition"
                ) { targetRoute ->
                    when (targetRoute) {
                        ArcanaNavRoute.HOME -> {
                            HomeScreen(
                                isEnglish = isEnglish,
                                onStartReading = {
                                    readingFlowState = ReadingFlowState.SELECT
                                    currentRoute = ArcanaNavRoute.READING
                                },
                                onSelectSpread = { spreadId ->
                                    selectedSpread = SpreadsData.getById(spreadId) ?: SpreadsData.threeSituationChallengeAdvice
                                    readingFlowState = ReadingFlowState.SELECT
                                    currentRoute = ArcanaNavRoute.READING
                                },
                                onExploreArcana = {
                                    currentRoute = ArcanaNavRoute.LIBRARY
                                },
                                onCardClick = { card ->
                                    inspectCard = card
                                    inspectCardReversed = false
                                }
                            )
                        }

                        ArcanaNavRoute.READING -> {
                            when (readingFlowState) {
                                ReadingFlowState.SELECT -> {
                                    ReadingSelectScreen(
                                        initialSpreadId = selectedSpread.id,
                                        isEnglish = isEnglish,
                                        allowReversalsDefault = allowReversals,
                                        onProceedToSession = { spread, name, question, backstory, allowRev ->
                                            selectedSpread = spread
                                            currentUserName = name
                                            currentUserQuestion = question
                                            currentUserBackstory = backstory
                                            currentAllowReversals = allowRev
                                            readingFlowState = ReadingFlowState.SESSION
                                        }
                                    )
                                }

                                ReadingFlowState.SESSION -> {
                                    ReadingSessionScreen(
                                        spread = selectedSpread,
                                        userName = currentUserName,
                                        userQuestion = currentUserQuestion,
                                        userBackstory = currentUserBackstory,
                                        allowReversals = currentAllowReversals,
                                        enableHaptics = enableHaptics,
                                        isEnglish = isEnglish,
                                        onCompleteReading = { drawnPairs ->
                                            val generated = TarotInterpretationEngine.generateResult(
                                                spreadType = selectedSpread,
                                                drawnCards = drawnPairs,
                                                userName = currentUserName,
                                                userQuestion = currentUserQuestion,
                                                userBackstory = currentUserBackstory,
                                                isEn = isEnglish
                                            )
                                            currentReadingResult = generated
                                            readingFlowState = ReadingFlowState.RESULT
                                        },
                                        onCancel = {
                                            readingFlowState = ReadingFlowState.SELECT
                                        }
                                    )
                                }

                                ReadingFlowState.RESULT -> {
                                    if (currentReadingResult != null) {
                                        ReadingResultScreen(
                                            result = currentReadingResult!!,
                                            isEnglish = isEnglish,
                                            onNewReading = {
                                                readingFlowState = ReadingFlowState.SELECT
                                            }
                                        )
                                    } else {
                                        readingFlowState = ReadingFlowState.SELECT
                                    }
                                }
                            }
                        }

                        ArcanaNavRoute.LIBRARY -> {
                            LibraryScreen(
                                isEnglish = isEnglish,
                                onCardClick = { card ->
                                    inspectCard = card
                                    inspectCardReversed = false
                                }
                            )
                        }

                        ArcanaNavRoute.JOURNAL -> {
                            JournalScreen(
                                isEnglish = isEnglish,
                                onStartReading = {
                                    readingFlowState = ReadingFlowState.SELECT
                                    currentRoute = ArcanaNavRoute.READING
                                }
                            )
                        }

                        ArcanaNavRoute.ABOUT -> {
                            AboutScreen(
                                isEnglish = isEnglish
                            )
                        }

                        ArcanaNavRoute.SETTINGS -> {
                            SettingsScreen(
                                userPreferences = userPreferences,
                                isEnglish = isEnglish,
                                allowReversals = allowReversals,
                                enableHaptics = enableHaptics,
                                reducedMotion = reducedMotion
                            )
                        }
                    }
                }
            }
        }
    }

    // Inspect Card Bottom Sheet Modal
    if (inspectCard != null) {
        val card = inspectCard!!
        val sheetState = rememberModalBottomSheetState()
        val scrollState = rememberScrollState()

        ModalBottomSheet(
            onDismissRequest = { inspectCard = null },
            sheetState = sheetState,
            containerColor = ObsidianCard
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${card.arcana.titleId} • ${card.astrologySymbol}",
                            color = AntiqueGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isEnglish) card.nameEn else card.nameId,
                            color = LightAntiqueGold,
                            fontSize = 20.sp,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(onClick = { inspectCard = null }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = MoonSilver)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TarotCardView(
                        card = card,
                        isRevealed = true,
                        isReversed = inspectCardReversed,
                        modifier = Modifier.width(130.dp),
                        isEnglish = isEnglish,
                        showDetailedBadges = true
                    )

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (inspectCardReversed)
                                    if (isEnglish) "Reversed" else "Terbalik"
                                else
                                    if (isEnglish) "Upright" else "Tegak",
                                color = if (inspectCardReversed) ReversalAmber else CelestialCyan,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Switch(
                                checked = inspectCardReversed,
                                onCheckedChange = { inspectCardReversed = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = ReversalAmber,
                                    checkedTrackColor = DeepViolet,
                                    uncheckedThumbColor = CelestialCyan,
                                    uncheckedTrackColor = ObsidianSurface
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "Elemen: ${card.element}", color = MoonSilver, fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (isEnglish) "Keywords" else "Kata Kunci",
                            color = AntiqueGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isEnglish) card.keywordsEn else card.keywordsId,
                            color = MoonSilver,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                    border = BorderStroke(0.6.dp, GoldBorderSubtle),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (inspectCardReversed)
                                if (isEnglish) "Reversed Meaning" else "Makna Terbalik (Reversed)"
                            else
                                if (isEnglish) "Upright Meaning" else "Makna Tegak (Upright)",
                            color = if (inspectCardReversed) ReversalAmber else LightAntiqueGold,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (inspectCardReversed)
                                if (isEnglish) card.reversedEn else card.reversedId
                            else
                                if (isEnglish) card.uprightEn else card.uprightId,
                            color = MoonSilver,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))
            }
        }
    }
}

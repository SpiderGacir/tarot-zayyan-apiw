package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AntiqueGold
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.LightAntiqueGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MoonSilver
import com.example.ui.theme.ObsidianSurface

@Composable
fun ArcanaHeader(
    isEnglish: Boolean,
    onToggleLanguage: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(MidnightNavy.copy(alpha = 0.95f))
            .border(
                width = 0.8.dp,
                color = GoldBorderSubtle,
                shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp)
            )
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Logo and Brand Name
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(ObsidianSurface)
                    .border(1.dp, AntiqueGold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "☾✦",
                    color = AntiqueGold,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column {
                Text(
                    text = "ARCANA NOCTIS",
                    color = LightAntiqueGold,
                    fontSize = 15.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
                Text(
                    text = if (isEnglish) "Discover the Symbols" else "Pahami Diri Melalui Simbol",
                    color = MoonSilver.copy(alpha = 0.8f),
                    fontSize = 10.sp,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 0.5.sp
                )
            }
        }

        // Language Switch Button
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(ObsidianSurface)
                .border(1.dp, AntiqueGold.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                .clickable { onToggleLanguage() }
                .padding(horizontal = 10.dp, vertical = 6.dp)
                .testTag("language_toggle_button"),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Translate,
                    contentDescription = "Ganti Bahasa / Change Language",
                    tint = AntiqueGold,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isEnglish) "EN" else "ID",
                    color = LightAntiqueGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ArcanaDarkColorScheme = darkColorScheme(
    primary = AntiqueGold,
    onPrimary = Obsidian,
    primaryContainer = ObsidianCardElevated,
    onPrimaryContainer = LightAntiqueGold,
    secondary = MutedViolet,
    onSecondary = Obsidian,
    secondaryContainer = DeepViolet,
    onSecondaryContainer = LightViolet,
    tertiary = MoonSilver,
    onTertiary = Obsidian,
    background = MidnightNavy,
    onBackground = OffWhite,
    surface = Obsidian,
    onSurface = OffWhite,
    surfaceVariant = ObsidianSurface,
    onSurfaceVariant = MoonSilver,
    outline = GoldBorder,
    outlineVariant = DarkBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Preserve Arcana Noctis signature palette
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = ArcanaDarkColorScheme,
        typography = Typography,
        content = content
    )
}

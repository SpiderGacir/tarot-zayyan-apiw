package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.ArcanaType
import com.example.data.TarotCard
import com.example.data.TarotSuit
import com.example.ui.theme.AntiqueGold
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.LightAntiqueGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MoonSilver
import com.example.ui.theme.MutedGold
import com.example.ui.theme.MutedViolet
import com.example.ui.theme.Obsidian
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ReversalAmber

@Composable
fun TarotCardView(
    card: TarotCard?,
    isRevealed: Boolean = true,
    isReversed: Boolean = false,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    isEnglish: Boolean = false,
    showDetailedBadges: Boolean = true
) {
    val rotationY by animateFloatAsState(
        targetValue = if (isRevealed) 0f else 180f,
        animationSpec = tween(durationMillis = 600),
        label = "card_flip"
    )

    Card(
        modifier = modifier
            .aspectRatio(0.62f)
            .graphicsLayer {
                this.rotationY = rotationY
                cameraDistance = 14f * density
            }
            .clip(RoundedCornerShape(10.dp))
            .testTag("tarot_card_${card?.id ?: "back"}"),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.2.dp, GoldBorder),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
        ) {
            if (rotationY > 90f || card == null) {
                // Card Back (Rotated 180 horizontally to counter mirror)
                CardBackContent(modifier = Modifier.graphicsLayer { this.rotationY = 180f })
            } else {
                // Card Front
                CardFrontContent(
                    card = card,
                    isReversed = isReversed,
                    isEnglish = isEnglish,
                    showDetailedBadges = showDetailedBadges
                )
            }
        }
    }
}

@Composable
private fun CardBackContent(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(MidnightNavy, Obsidian, DeepViolet.copy(alpha = 0.5f), MidnightNavy)
                )
            )
            .padding(6.dp)
    ) {
        // Inner ornamental frame
        Box(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, GoldBorder.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                .padding(4.dp)
        ) {
            // Symmetrical celestial sacred geometry
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width / 2f
                val cy = size.height / 2f
                val minDim = minOf(size.width, size.height)

                // Central emblem circle
                drawCircle(
                    color = AntiqueGold.copy(alpha = 0.35f),
                    radius = minDim * 0.28f,
                    center = Offset(cx, cy),
                    style = Stroke(width = 1.5f)
                )
                drawCircle(
                    color = MutedGold.copy(alpha = 0.2f),
                    radius = minDim * 0.18f,
                    center = Offset(cx, cy),
                    style = Stroke(width = 1f)
                )

                // Four diagonal star rays
                val rayLen = minDim * 0.36f
                drawLine(
                    color = AntiqueGold.copy(alpha = 0.4f),
                    start = Offset(cx - rayLen, cy),
                    end = Offset(cx + rayLen, cy),
                    strokeWidth = 1f
                )
                drawLine(
                    color = AntiqueGold.copy(alpha = 0.4f),
                    start = Offset(cx, cy - rayLen),
                    end = Offset(cx, cy + rayLen),
                    strokeWidth = 1f
                )

                // Corner celestial ornaments
                val cornerPad = 12f
                drawCircle(AntiqueGold.copy(alpha = 0.4f), radius = 2f, center = Offset(cornerPad, cornerPad))
                drawCircle(AntiqueGold.copy(alpha = 0.4f), radius = 2f, center = Offset(size.width - cornerPad, cornerPad))
                drawCircle(AntiqueGold.copy(alpha = 0.4f), radius = 2f, center = Offset(cornerPad, size.height - cornerPad))
                drawCircle(AntiqueGold.copy(alpha = 0.4f), radius = 2f, center = Offset(size.width - cornerPad, size.height - cornerPad))
            }

            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "☾ ✦ ☽",
                    color = AntiqueGold,
                    fontSize = 14.sp,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "ARCANA",
                    color = MutedGold,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.5.sp
                )
            }
        }
    }
}

@Composable
private fun CardFrontContent(
    card: TarotCard,
    isReversed: Boolean,
    isEnglish: Boolean,
    showDetailedBadges: Boolean
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Obsidian,
                        MidnightNavy,
                        Obsidian
                    )
                )
            )
            .padding(6.dp)
    ) {
        // Inner golden border
        Column(
            modifier = Modifier
                .fillMaxSize()
                .border(0.8.dp, GoldBorder.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header: Rank / Number & Suit
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = card.number,
                    color = LightAntiqueGold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = card.astrologySymbol.take(3),
                    color = MoonSilver.copy(alpha = 0.7f),
                    fontSize = 9.sp
                )
            }

            // Center Artwork: Stylized engraved celestial medallion
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                // If reversed, visually rotate the central artwork 180 degrees
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .then(if (isReversed) Modifier.rotate(180f) else Modifier),
                    contentAlignment = Alignment.Center
                ) {
                    CardSymbolCanvas(card = card)
                }

                // Reversal Ribbon indicator
                if (isReversed && showDetailedBadges) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .clip(RoundedCornerShape(4.dp))
                            .background(ReversalAmber.copy(alpha = 0.9f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (isEnglish) "REVERSED" else "TERBALIK",
                            color = Obsidian,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            // Footer: Name & keywords preview
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                val displayName = if (isEnglish) card.nameEn else card.nameId
                Text(
                    text = displayName,
                    color = LightAntiqueGold,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                if (showDetailedBadges) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (isEnglish) card.keywordsEn else card.keywordsId,
                        color = MoonSilver.copy(alpha = 0.75f),
                        fontSize = 8.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun CardSymbolCanvas(card: TarotCard) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val rad = minOf(size.width, size.height) * 0.38f

        // Outer engraved ring
        drawCircle(
            color = AntiqueGold.copy(alpha = 0.45f),
            radius = rad,
            center = Offset(cx, cy),
            style = Stroke(width = 1.2f)
        )
        drawCircle(
            color = MutedViolet.copy(alpha = 0.25f),
            radius = rad * 0.8f,
            center = Offset(cx, cy),
            style = Stroke(width = 0.8f)
        )

        // Suit / Arcana specific geometries
        when (card.suit) {
            TarotSuit.WANDS -> {
                // Flaming Wand / Vertical Staff
                drawLine(
                    color = AntiqueGold,
                    start = Offset(cx, cy + rad * 0.7f),
                    end = Offset(cx, cy - rad * 0.7f),
                    strokeWidth = 2.5f
                )
                // Fire rays
                drawCircle(AntiqueGold.copy(alpha = 0.7f), radius = 5f, center = Offset(cx, cy - rad * 0.7f))
                drawLine(AntiqueGold.copy(alpha = 0.4f), Offset(cx - 10f, cy - rad * 0.5f), Offset(cx + 10f, cy - rad * 0.5f), 1.5f)
                drawLine(AntiqueGold.copy(alpha = 0.4f), Offset(cx - 14f, cy - rad * 0.2f), Offset(cx + 14f, cy - rad * 0.2f), 1.5f)
            }
            TarotSuit.CUPS -> {
                // Sacred Chalice
                drawLine(AntiqueGold, Offset(cx - rad * 0.4f, cy - rad * 0.2f), Offset(cx + rad * 0.4f, cy - rad * 0.2f), 2f)
                drawLine(AntiqueGold, Offset(cx - rad * 0.35f, cy - rad * 0.2f), Offset(cx, cy + rad * 0.25f), 2f)
                drawLine(AntiqueGold, Offset(cx + rad * 0.35f, cy - rad * 0.2f), Offset(cx, cy + rad * 0.25f), 2f)
                drawLine(AntiqueGold, Offset(cx, cy + rad * 0.25f), Offset(cx, cy + rad * 0.6f), 2f)
                drawLine(AntiqueGold, Offset(cx - rad * 0.3f, cy + rad * 0.6f), Offset(cx + rad * 0.3f, cy + rad * 0.6f), 2.5f)
            }
            TarotSuit.SWORDS -> {
                // Upright Steel Blade
                drawLine(MoonSilver, Offset(cx, cy + rad * 0.65f), Offset(cx, cy - rad * 0.7f), 2f)
                // Crossguard
                drawLine(AntiqueGold, Offset(cx - rad * 0.35f, cy + rad * 0.35f), Offset(cx + rad * 0.35f, cy + rad * 0.35f), 2.5f)
                // Pommel
                drawCircle(AntiqueGold, radius = 3.5f, center = Offset(cx, cy + rad * 0.65f))
            }
            TarotSuit.PENTACLES -> {
                // Golden 5-pointed star pentacle
                drawCircle(AntiqueGold, radius = rad * 0.55f, center = Offset(cx, cy), style = Stroke(width = 1.5f))
                drawCircle(AntiqueGold.copy(alpha = 0.6f), radius = 4f, center = Offset(cx, cy))
                // Diamond rays
                drawLine(MutedGold, Offset(cx - rad * 0.45f, cy), Offset(cx + rad * 0.45f, cy), 1f)
                drawLine(MutedGold, Offset(cx, cy - rad * 0.45f), Offset(cx, cy + rad * 0.45f), 1f)
            }
            TarotSuit.NONE -> {
                // Major Arcana Celestial Sun & Crescent Moon
                drawCircle(AntiqueGold, radius = rad * 0.45f, center = Offset(cx, cy), style = Stroke(width = 1.5f))
                // Crescent inner shadow
                drawCircle(MidnightNavy, radius = rad * 0.35f, center = Offset(cx + rad * 0.18f, cy - rad * 0.1f))
                // 4-pointed star
                val starLen = rad * 0.65f
                drawLine(AntiqueGold.copy(alpha = 0.6f), Offset(cx - starLen, cy), Offset(cx + starLen, cy), 1f)
                drawLine(AntiqueGold.copy(alpha = 0.6f), Offset(cx, cy - starLen), Offset(cx, cy + starLen), 1f)
            }
        }
    }
}

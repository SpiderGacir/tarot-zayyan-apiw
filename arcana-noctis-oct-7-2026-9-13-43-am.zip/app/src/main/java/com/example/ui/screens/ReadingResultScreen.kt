package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CardInterpretation
import com.example.data.ReadingResult
import com.example.data.local.ArcanaDatabase
import com.example.data.local.ReadingEntity
import com.example.ui.components.TarotCardView
import com.example.ui.theme.AntiqueGold
import com.example.ui.theme.CelestialCyan
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.LightAntiqueGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MoonSilver
import com.example.ui.theme.MutedGold
import com.example.ui.theme.MutedText
import com.example.ui.theme.MutedViolet
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ReversalAmber
import kotlinx.coroutines.launch

@Composable
fun ReadingResultScreen(
    result: ReadingResult,
    isEnglish: Boolean,
    onNewReading: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    var isSavedToJournal by remember { mutableStateOf(false) }
    var focusedCardIndex by remember { mutableIntStateOf(0) }
    var showAllInterpretations by remember { mutableStateOf(false) }

    fun copySummary() {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val text = buildString {
            appendLine(result.title)
            appendLine(result.formattedDate)
            appendLine("—".repeat(20))
            appendLine("Ringkasan Eksekutif:")
            appendLine(result.executiveSummary)
            appendLine()
            appendLine("Energi Dominan: ${result.dominantEnergy}")
            appendLine()
            appendLine("Kartu yang Terpilih:")
            result.cardInterpretations.forEach {
                val name = if (isEnglish) it.card.nameEn else it.card.nameId
                val pos = if (isEnglish) it.position.titleEn else it.position.titleId
                val rev = if (it.isReversed) "(Reversed)" else "(Upright)"
                appendLine("- $pos: $name $rev")
            }
            appendLine()
            appendLine("Arcana Noctis by Zayyan Apiw Pradipta")
        }
        val clip = ClipData.newPlainText("Arcana Reading Summary", text)
        clipboard?.setPrimaryClip(clip)
        Toast.makeText(
            context,
            if (isEnglish) "Summary copied to clipboard!" else "Ringkasan berhasil disalin!",
            Toast.LENGTH_SHORT
        ).show()
    }

    fun shareReading() {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, "${result.title}\n\n${result.executiveSummary}\n\nArcana Noctis by Zayyan Apiw Pradipta")
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, if (isEnglish) "Share Reading" else "Bagikan Hasil Reading")
        context.startActivity(shareIntent)
    }

    fun saveToJournal() {
        if (isSavedToJournal) return
        coroutineScope.launch {
            val db = ArcanaDatabase.getInstance(context)
            val entity = ReadingEntity(
                timestamp = result.timestamp,
                formattedDate = result.formattedDate,
                spreadId = result.spreadType.id,
                spreadName = if (isEnglish) result.spreadType.nameEn else result.spreadType.nameId,
                userName = result.userName,
                question = result.userQuestion,
                backstory = result.userBackstory,
                customTitle = result.title,
                personalNotes = "",
                isFavorite = false,
                cardIds = result.cardInterpretations.joinToString(",") { it.card.id },
                cardReversals = result.cardInterpretations.joinToString(",") { it.isReversed.toString() },
                executiveSummary = result.executiveSummary,
                dominantEnergy = result.dominantEnergy,
                fullSynthesis = result.crossCardSynthesis
            )
            db.readingDao().insert(entity)
            isSavedToJournal = true
            Toast.makeText(
                context,
                if (isEnglish) "Reading saved to Journal!" else "Reading berhasil disimpan ke Jurnal!",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("reading_result_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Result Title & Metadata Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = BorderStroke(1.2.dp, GoldBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(ObsidianSurface)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (isEnglish) result.spreadType.nameEn else result.spreadType.nameId,
                        color = AntiqueGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = result.title,
                    color = LightAntiqueGold,
                    fontSize = 18.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 24.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "${result.formattedDate} • ${result.userName}",
                    color = MoonSilver.copy(alpha = 0.75f),
                    fontSize = 11.sp
                )

                if (result.userBackstory.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Konteks: ${result.userBackstory}",
                        color = MoonSilver.copy(alpha = 0.7f),
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        maxLines = 3
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Executive Summary Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCardElevated),
            border = BorderStroke(1.dp, AntiqueGold.copy(alpha = 0.6f)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = AntiqueGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isEnglish) "Executive Summary" else "Ringkasan Tema Utama",
                        color = LightAntiqueGold,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = result.executiveSummary,
                    color = MoonSilver,
                    fontSize = 13.sp,
                    lineHeight = 20.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Spread Cards Row (Interactive)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isEnglish) "Drawn Arcana Spread" else "Susunan Kartu Terpilih",
                color = LightAntiqueGold,
                fontSize = 15.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (isEnglish) "Tap card to inspect" else "Ketuk kartu untuk fokus",
                color = MoonSilver.copy(alpha = 0.6f),
                fontSize = 11.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            itemsIndexed(result.cardInterpretations) { idx, item ->
                val isFocused = focusedCardIndex == idx
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.width(110.dp)
                ) {
                    // Position badge
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isFocused) AntiqueGold else ObsidianSurface)
                            .padding(vertical = 3.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isEnglish) item.position.titleEn else item.position.titleId,
                            color = if (isFocused) MidnightNavy else LightAntiqueGold,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            maxLines = 1
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    TarotCardView(
                        card = item.card,
                        isRevealed = true,
                        isReversed = item.isReversed,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(170.dp)
                            .then(
                                if (isFocused) Modifier.border(2.dp, AntiqueGold, RoundedCornerShape(10.dp))
                                else Modifier
                            ),
                        isEnglish = isEnglish,
                        showDetailedBadges = true,
                        onClick = { focusedCardIndex = idx }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Focused Card Deep Dive
        val focusedItem = result.cardInterpretations.getOrNull(focusedCardIndex)
        if (focusedItem != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(1.dp, AntiqueGold.copy(alpha = 0.7f)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isEnglish) focusedItem.position.titleEn else focusedItem.position.titleId,
                                color = AntiqueGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isEnglish) focusedItem.card.nameEn else focusedItem.card.nameId,
                                color = LightAntiqueGold,
                                fontSize = 16.sp,
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (focusedItem.isReversed) ReversalAmber else CelestialCyan)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (focusedItem.isReversed)
                                    if (isEnglish) "REVERSED" else "TERBALIK"
                                else
                                    if (isEnglish) "UPRIGHT" else "TEGAK",
                                color = MidnightNavy,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = focusedItem.detailedAnalysis,
                        color = MoonSilver,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Shadow & reflection
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = if (isEnglish) "Shadow Aspect to Watch:" else "Aspek Bayangan yang Perlu Diwaspadai:",
                                color = MutedViolet,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = focusedItem.shadowWarning,
                                color = MoonSilver.copy(alpha = 0.85f),
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Toggle Read All Interpretations
        OutlinedButton(
            onClick = { showAllInterpretations = !showAllInterpretations },
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(0.8.dp, AntiqueGold.copy(alpha = 0.6f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(
                imageVector = if (showAllInterpretations) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = null,
                tint = AntiqueGold,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (showAllInterpretations)
                    if (isEnglish) "Collapse All Interpretations" else "Tutup Seluruh Interpretasi"
                else
                    if (isEnglish) "Read All Card Interpretations" else "Baca Seluruh Kartu Secara Lengkap",
                color = LightAntiqueGold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Serif
            )
        }

        AnimatedVisibility(visible = showAllInterpretations) {
            Column(modifier = Modifier.padding(top = 10.dp)) {
                result.cardInterpretations.forEachIndexed { i, itm ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                        border = BorderStroke(0.6.dp, GoldBorderSubtle),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${i + 1}. ${if (isEnglish) itm.position.titleEn else itm.position.titleId}",
                                    color = AntiqueGold,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (itm.isReversed) if (isEnglish) "Reversed" else "Terbalik" else if (isEnglish) "Upright" else "Tegak",
                                    color = if (itm.isReversed) ReversalAmber else CelestialCyan,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isEnglish) itm.card.nameEn else itm.card.nameId,
                                color = LightAntiqueGold,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = itm.specificMeaning,
                                color = MoonSilver,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Cross-Card Synthesis & Dominant Energies
        SynthesisSection(
            title = if (isEnglish) "Dominant Archetype & Energy" else "Energi & Arketipe Dominan",
            body = result.dominantEnergy,
            color = AntiqueGold
        )

        Spacer(modifier = Modifier.height(12.dp))

        SynthesisSection(
            title = if (isEnglish) "Cross-Card Dialogue & Synergy" else "Analisis Dialog Antarkartu",
            body = result.crossCardSynthesis,
            color = MutedViolet
        )

        Spacer(modifier = Modifier.height(12.dp))

        SynthesisSection(
            title = if (isEnglish) "Tensions, Friction & Internal Conflicts" else "Ketegangan & Kontradiksi Batin",
            body = result.tensionsAndConflicts,
            color = ReversalAmber
        )

        Spacer(modifier = Modifier.height(12.dp))

        SynthesisSection(
            title = if (isEnglish) "Emerging Scenarios (Symbolic)" else "Kemungkinan Skenario Perkembangan",
            body = result.realisticScenarios,
            color = CelestialCyan
        )

        Spacer(modifier = Modifier.height(12.dp))

        SynthesisSection(
            title = if (isEnglish) "Blind Spots to Watch" else "Hal yang Perlu Diwaspadai (Blind Spot)",
            body = result.blindSpotsToWatch,
            color = LightAntiqueGold
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Actionable Advice Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = BorderStroke(1.dp, GoldBorder.copy(alpha = 0.8f)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isEnglish) "Actionable Advice (Next Steps)" else "Saran Tindakan yang Realistis",
                    color = LightAntiqueGold,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))
                result.actionableAdvice.forEachIndexed { idx, adv ->
                    Row(
                        modifier = Modifier.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "${idx + 1}. ",
                            color = AntiqueGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = adv,
                            color = MoonSilver,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Journaling Prompts
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = BorderStroke(0.8.dp, GoldBorderSubtle),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isEnglish) "Journaling Prompts for Self-Reflection" else "Pertanyaan Refleksi untuk Jurnal",
                    color = LightAntiqueGold,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))
                result.journalingPrompts.forEach { prompt ->
                    Text(
                        text = "• \"$prompt\"",
                        color = MoonSilver,
                        fontSize = 12.sp,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        lineHeight = 18.sp,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Personal Closing Synthesis
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
            border = BorderStroke(0.6.dp, AntiqueGold.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isEnglish) "Closing Wisdom" else "Kesimpulan & Penutup Personal",
                    color = LightAntiqueGold,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = result.closingSynthesis,
                    color = MoonSilver,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Ethical Disclaimer
        Text(
            text = result.ethicalDisclaimer,
            color = MutedText,
            fontSize = 10.sp,
            textAlign = TextAlign.Center,
            lineHeight = 14.sp,
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Primary Actions: Save, Copy, Share, New Reading
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { saveToJournal() },
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .testTag("save_reading_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isSavedToJournal) DeepViolet else AntiqueGold,
                    contentColor = if (isSavedToJournal) LightAntiqueGold else MidnightNavy
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = if (isSavedToJournal) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isSavedToJournal)
                        if (isEnglish) "Saved!" else "Tersimpan"
                    else
                        if (isEnglish) "Save Reading" else "Simpan Reading",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            OutlinedButton(
                onClick = { copySummary() },
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .testTag("copy_summary_button"),
                border = BorderStroke(1.dp, AntiqueGold.copy(alpha = 0.7f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = AntiqueGold, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isEnglish) "Copy Summary" else "Salin Inti",
                    color = LightAntiqueGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = { shareReading() },
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("share_reading_button"),
                border = BorderStroke(0.8.dp, MoonSilver.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, tint = MoonSilver, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isEnglish) "Share" else "Bagikan",
                    color = MoonSilver,
                    fontSize = 12.sp
                )
            }

            Button(
                onClick = onNewReading,
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("new_reading_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ObsidianCardElevated,
                    contentColor = LightAntiqueGold
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isEnglish) "New Reading" else "Reading Baru",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

@Composable
private fun SynthesisSection(
    title: String,
    body: String,
    color: Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(0.6.dp, GoldBorderSubtle),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                color = color,
                fontSize = 13.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = body,
                color = MoonSilver,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )
        }
    }
}

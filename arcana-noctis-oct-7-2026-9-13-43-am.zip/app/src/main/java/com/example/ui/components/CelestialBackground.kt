package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.AntiqueGold
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MoonSilver
import com.example.ui.theme.Obsidian
import kotlin.random.Random

private data class StarParticle(
    val xRatio: Float,
    val yRatio: Float,
    val radius: Float,
    val alphaPhase: Float,
    val isGold: Boolean
)

@Composable
fun CelestialBackground(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "star_twinkle")
    val twinkleFactor by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "twinkle"
    )

    val stars = remember {
        val rand = Random(42)
        List(60) {
            StarParticle(
                xRatio = rand.nextFloat(),
                yRatio = rand.nextFloat(),
                radius = 1f + rand.nextFloat() * 1.8f,
                alphaPhase = rand.nextFloat(),
                isGold = rand.nextBoolean()
            )
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Cosmic atmospheric radial gradient
            val bgBrush = Brush.radialGradient(
                colors = listOf(
                    DeepViolet.copy(alpha = 0.28f),
                    Obsidian,
                    MidnightNavy
                ),
                center = Offset(w * 0.5f, h * 0.15f),
                radius = (w + h) * 0.6f
            )
            drawRect(brush = bgBrush)

            // Celestial delicate orbit lines
            drawCircle(
                color = AntiqueGold.copy(alpha = 0.04f),
                radius = w * 0.7f,
                center = Offset(w * 0.5f, h * 0.2f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1f)
            )
            drawCircle(
                color = MoonSilver.copy(alpha = 0.03f),
                radius = w * 0.45f,
                center = Offset(w * 0.5f, h * 0.2f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1f)
            )

            // Twinkling stars
            stars.forEach { star ->
                val dynamicAlpha = ((star.alphaPhase + twinkleFactor) % 1f).coerceIn(0.15f, 0.85f)
                val starColor = if (star.isGold) {
                    AntiqueGold.copy(alpha = dynamicAlpha * 0.8f)
                } else {
                    MoonSilver.copy(alpha = dynamicAlpha * 0.7f)
                }
                drawCircle(
                    color = starColor,
                    radius = star.radius,
                    center = Offset(star.xRatio * w, star.yRatio * h)
                )
            }
        }
        content()
    }
}

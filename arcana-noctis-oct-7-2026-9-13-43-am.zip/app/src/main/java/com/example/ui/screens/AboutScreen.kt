package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AntiqueGold
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.LightAntiqueGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MoonSilver
import com.example.ui.theme.MutedText
import com.example.ui.theme.MutedViolet
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianSurface

@Composable
fun AboutScreen(
    isEnglish: Boolean,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("about_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Altar Emblem
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(ObsidianSurface)
                .border(1.5.dp, AntiqueGold, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "☾✦☽",
                color = AntiqueGold,
                fontSize = 24.sp
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "ARCANA NOCTIS",
            color = LightAntiqueGold,
            fontSize = 24.sp,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "Designed & Created by Zayyan Apiw Pradipta",
            color = AntiqueGold,
            fontSize = 13.sp,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Manifesto Box
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = BorderStroke(1.dp, GoldBorder),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isEnglish)
                        "\"Arcana Noctis is an independent digital experience exploring tarot symbolism, personal reflection, and interactive storytelling.\""
                    else
                        "\"Arcana Noctis adalah pengalaman digital independen yang mengeksplorasi simbolisme tarot, refleksi diri, dan storytelling interaktif.\"",
                    color = LightAntiqueGold,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Serif,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .height(1.dp)
                        .width(60.dp)
                        .background(AntiqueGold.copy(alpha = 0.5f))
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Concept, Design & Digital Experience by Zayyan Apiw Pradipta",
                    color = MoonSilver,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Serif,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Creative Process Timeline
        Text(
            text = if (isEnglish) "Creative Process & Architecture" else "Proses Kreatif & Struktur Proyek",
            color = LightAntiqueGold,
            fontSize = 16.sp,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(14.dp))

        TimelineItem(
            step = "01",
            title = if (isEnglish) "Concept & Research" else "Riset & Konseptualisasi",
            body = if (isEnglish)
                "Mengkaji simbolisme esoterik 78 kartu Rider-Waite-Smith serta psikologi arketipe Carl Jung untuk merumuskan refleksi batin yang berdaya, jujur, dan tidak deterministik."
            else
                "Mengkaji simbolisme esoterik 78 kartu Rider-Waite-Smith serta psikologi arketipe Carl Jung untuk merumuskan refleksi batin yang berdaya, jujur, dan tidak deterministik.",
            icon = Icons.Default.Psychology
        )

        Spacer(modifier = Modifier.height(10.dp))

        TimelineItem(
            step = "02",
            title = if (isEnglish) "Visual Identity & Engraving" else "Identitas Visual & Ornamen Engraved",
            body = if (isEnglish)
                "Merancang palet warna midnight obsidian (#090B16), filigree emas antik (#D8B777), dan ilustrasi celestial geometris yang elegan dan atmosferik tanpa mengorbankan keterbacaan."
            else
                "Merancang palet warna midnight obsidian (#090B16), filigree emas antik (#D8B777), dan ilustrasi celestial geometris yang elegan dan atmosferik tanpa mengorbankan keterbacaan.",
            icon = Icons.Default.Brush
        )

        Spacer(modifier = Modifier.height(10.dp))

        TimelineItem(
            step = "03",
            title = if (isEnglish) "Interactive Ritual Experience" else "Pengalaman Ritual Interaktif",
            body = if (isEnglish)
                "Menciptakan ritual penarikan kartu digital dengan rasa taktil, animasi rotasi 3D flip, getaran haptik halus, dan keheningan kontemplasi sebelum membaca hasil."
            else
                "Menciptakan ritual penarikan kartu digital dengan rasa taktil, animasi rotasi 3D flip, getaran haptik halus, dan keheningan kontemplasi sebelum membaca hasil.",
            icon = Icons.Default.AutoAwesome
        )

        Spacer(modifier = Modifier.height(10.dp))

        TimelineItem(
            step = "04",
            title = if (isEnglish) "Tarot Interpretation System" else "Sistem Interpretasi Simbolik",
            body = if (isEnglish)
                "Mengembangkan mesin interpretasi berbasis posisi spread, analisis silang elemen (Api, Air, Udara, Tanah), identifikasi blind spots, dan saran tindakan realistis."
            else
                "Mengembangkan mesin interpretasi berbasis posisi spread, analisis silang elemen (Api, Air, Udara, Tanah), identifikasi blind spots, dan saran tindakan realistis.",
            icon = Icons.Default.Shield
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Ethical Principles & Transparency
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = BorderStroke(0.8.dp, GoldBorderSubtle),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isEnglish) "Ethical Tarot Principles" else "Prinsip Etika & Transparansi",
                    color = LightAntiqueGold,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isEnglish)
                        "1. Arcana Noctis tidak mengklaim kemampuan meramal masa depan secara mutlak atau membaca pikiran orang lain secara gaib.\n\n2. Hasil pembacaan tidak menggunakan taktik manipulasi harapan palsu.\n\n3. Semua data disimpan secara privat di perangkatmu tanpa pelacakan atau transmisi pihak ketiga."
                    else
                        "1. Arcana Noctis tidak mengklaim kemampuan meramal masa depan secara mutlak atau membaca pikiran orang lain secara gaib.\n\n2. Hasil pembacaan tidak menggunakan taktik manipulasi harapan palsu, janji palsu, atau dorongan melanggar batasan komunikasi orang lain.\n\n3. Semua riwayat reading dan catatan pribadi tersimpan secara privat di penyimpanan lokal perangkatmu tanpa pelacakan pihak ketiga.",
                    color = MoonSilver,
                    fontSize = 11.sp,
                    lineHeight = 17.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(50.dp))
    }
}

@Composable
private fun TimelineItem(
    step: String,
    title: String,
    body: String,
    icon: ImageVector
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(0.6.dp, GoldBorderSubtle),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(DeepViolet.copy(alpha = 0.4f))
                    .border(0.8.dp, AntiqueGold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(text = step, color = LightAntiqueGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = LightAntiqueGold,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = body,
                    color = MoonSilver.copy(alpha = 0.85f),
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AntiqueGold
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.LightAntiqueGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MoonSilver
import com.example.ui.theme.MutedText
import com.example.ui.theme.ObsidianCard

enum class ArcanaNavRoute(
    val titleId: String,
    val titleEn: String,
    val icon: ImageVector,
    val testTag: String
) {
    HOME("Beranda", "Home", Icons.Default.Home, "nav_home"),
    READING("Reading", "Reading", Icons.Default.AutoAwesome, "nav_reading"),
    LIBRARY("Katalog", "Library", Icons.AutoMirrored.Filled.MenuBook, "nav_library"),
    JOURNAL("Jurnal", "Journal", Icons.Default.Bookmark, "nav_journal"),
    ABOUT("Tentang", "About", Icons.Default.Info, "nav_about"),
    SETTINGS("Setelan", "Settings", Icons.Default.Settings, "nav_settings")
}

@Composable
fun ArcanaBottomNav(
    currentRoute: ArcanaNavRoute,
    onNavigate: (ArcanaNavRoute) -> Unit,
    isEnglish: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(MidnightNavy.copy(alpha = 0.96f))
            .border(
                width = 0.8.dp,
                color = GoldBorderSubtle,
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
            )
            .navigationBarsPadding()
            .padding(horizontal = 6.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ArcanaNavRoute.values().forEach { route ->
                val isSelected = currentRoute == route
                val label = if (isEnglish) route.titleEn else route.titleId

                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .then(
                            if (isSelected) Modifier.background(ObsidianCard) else Modifier
                        )
                        .clickable { onNavigate(route) }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .testTag(route.testTag),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = route.icon,
                        contentDescription = label,
                        tint = if (isSelected) AntiqueGold else MutedText,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = label,
                        color = if (isSelected) LightAntiqueGold else MutedText,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

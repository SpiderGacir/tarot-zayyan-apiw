package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ArcanaType
import com.example.data.TarotCard
import com.example.data.TarotRepository
import com.example.data.TarotSuit
import com.example.ui.components.TarotCardView
import com.example.ui.theme.AntiqueGold
import com.example.ui.theme.CelestialCyan
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.LightAntiqueGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MoonSilver
import com.example.ui.theme.MutedText
import com.example.ui.theme.MutedViolet
import com.example.ui.theme.Obsidian
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ReversalAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    isEnglish: Boolean,
    onCardClick: (TarotCard) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf<String>("ALL") }
    var isShuffledOrder by remember { mutableStateOf(false) }
    var shuffleSeed by remember { mutableStateOf(0) }

    var selectedCardForDetail by remember { mutableStateOf<TarotCard?>(null) }
    var isDetailReversed by remember { mutableStateOf(false) }

    val filterSuit = when (selectedFilter) {
        "WANDS" -> TarotSuit.WANDS
        "CUPS" -> TarotSuit.CUPS
        "SWORDS" -> TarotSuit.SWORDS
        "PENTACLES" -> TarotSuit.PENTACLES
        else -> null
    }

    val filterArcana = when (selectedFilter) {
        "MAJOR" -> ArcanaType.MAJOR
        else -> null
    }

    val filteredList = remember(searchQuery, selectedFilter, shuffleSeed) {
        val list = TarotRepository.filterCards(
            query = searchQuery,
            suit = filterSuit,
            arcana = filterArcana
        )
        if (isShuffledOrder) list.shuffled() else list
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("library_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (isEnglish) "Tarot Encyclopedia" else "Katalog 78 Kartu Arcana",
                    color = LightAntiqueGold,
                    fontSize = 20.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isEnglish) "${filteredList.size} cards available" else "${filteredList.size} kartu ditampilkan",
                    color = MoonSilver.copy(alpha = 0.7f),
                    fontSize = 11.sp
                )
            }

            // Shuffle display button
            IconButton(
                onClick = {
                    isShuffledOrder = true
                    shuffleSeed++
                },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(ObsidianCard)
                    .border(0.8.dp, GoldBorderSubtle, CircleShape)
                    .testTag("shuffle_library_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Shuffle,
                    contentDescription = "Shuffle",
                    tint = AntiqueGold,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_library_input"),
            placeholder = {
                Text(
                    text = if (isEnglish) "Search cards, keywords, elements..." else "Cari nama kartu, kata kunci, elemen...",
                    color = MutedText,
                    fontSize = 12.sp
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = AntiqueGold,
                    modifier = Modifier.size(18.dp)
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear",
                            tint = MoonSilver,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AntiqueGold,
                unfocusedBorderColor = GoldBorderSubtle,
                focusedTextColor = LightAntiqueGold,
                unfocusedTextColor = LightAntiqueGold
            ),
            shape = RoundedCornerShape(12.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Filter Chips Row
        val filters = listOf(
            "ALL" to (if (isEnglish) "All (78)" else "Semua (78)"),
            "MAJOR" to (if (isEnglish) "Major Arcana (22)" else "Major Arcana (22)"),
            "WANDS" to (if (isEnglish) "Wands (14)" else "Tongkat (14)"),
            "CUPS" to (if (isEnglish) "Cups (14)" else "Piala (14)"),
            "SWORDS" to (if (isEnglish) "Swords (14)" else "Pedang (14)"),
            "PENTACLES" to (if (isEnglish) "Pentacles (14)" else "Koin (14)")
        )

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filters.size) { idx ->
                val (fKey, fTitle) = filters[idx]
                val isSelected = selectedFilter == fKey
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) AntiqueGold else ObsidianCard)
                        .border(
                            width = 0.8.dp,
                            color = if (isSelected) AntiqueGold else GoldBorderSubtle,
                            shape = RoundedCornerShape(16.dp)
                        )
                        .clickable { selectedFilter = fKey }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("filter_chip_$fKey")
                ) {
                    Text(
                        text = fTitle,
                        color = if (isSelected) Obsidian else LightAntiqueGold,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Grid of Tarot Cards
        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "✦", color = AntiqueGold, fontSize = 28.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isEnglish) "No cards matching your query." else "Tidak ada kartu yang sesuai pencarian.",
                        color = MoonSilver,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = {
                            searchQuery = ""
                            selectedFilter = "ALL"
                        },
                        border = BorderStroke(0.8.dp, AntiqueGold.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = if (isEnglish) "Reset Filters" else "Reset Filter",
                            color = LightAntiqueGold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("cards_grid"),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 60.dp)
            ) {
                items(filteredList, key = { it.id }) { card ->
                    TarotCardView(
                        card = card,
                        isRevealed = true,
                        isReversed = false,
                        onClick = {
                            selectedCardForDetail = card
                            isDetailReversed = false
                        },
                        isEnglish = isEnglish,
                        showDetailedBadges = false
                    )
                }
            }
        }
    }

    // Modal Bottom Sheet for In-Depth Card Details
    if (selectedCardForDetail != null) {
        val card = selectedCardForDetail!!
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
        val modalScrollState = rememberScrollState()

        ModalBottomSheet(
            onDismissRequest = { selectedCardForDetail = null },
            sheetState = sheetState,
            containerColor = ObsidianCard,
            dragHandle = {
                Box(
                    modifier = Modifier
                        .padding(top = 10.dp)
                        .width(40.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(GoldBorder)
                )
            }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(modalScrollState)
                    .padding(horizontal = 20.dp, vertical = 10.dp)
                    .testTag("card_detail_modal")
            ) {
                // Header: Card Name, Number, Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${card.arcana.titleId} • ${card.astrologySymbol}",
                            color = AntiqueGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isEnglish) card.nameEn else card.nameId,
                            color = LightAntiqueGold,
                            fontSize = 20.sp,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(onClick = { selectedCardForDetail = null }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = MoonSilver)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Card Preview & Upright/Reversed Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TarotCardView(
                        card = card,
                        isRevealed = true,
                        isReversed = isDetailReversed,
                        modifier = Modifier.width(130.dp),
                        isEnglish = isEnglish,
                        showDetailedBadges = true
                    )

                    Spacer(modifier = Modifier.width(20.dp))

                    Column {
                        Text(
                            text = if (isEnglish) "Orientation" else "Orientasi Kartu",
                            color = MoonSilver,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (isDetailReversed)
                                    if (isEnglish) "Reversed" else "Terbalik"
                                else
                                    if (isEnglish) "Upright" else "Tegak",
                                color = if (isDetailReversed) ReversalAmber else CelestialCyan,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Switch(
                                checked = isDetailReversed,
                                onCheckedChange = { isDetailReversed = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = ReversalAmber,
                                    checkedTrackColor = DeepViolet,
                                    uncheckedThumbColor = CelestialCyan,
                                    uncheckedTrackColor = ObsidianSurface
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Elemen: ${card.element}",
                            color = MoonSilver.copy(alpha = 0.8f),
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Keywords
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (isEnglish) "Keywords" else "Kata Kunci",
                            color = AntiqueGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isEnglish) card.keywordsEn else card.keywordsId,
                            color = MoonSilver,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Meaning based on orientation
                DetailSection(
                    title = if (isDetailReversed)
                        if (isEnglish) "Reversed Meaning" else "Makna Terbalik (Reversed)"
                    else
                        if (isEnglish) "Upright Meaning" else "Makna Tegak (Upright)",
                    body = if (isDetailReversed)
                        if (isEnglish) card.reversedEn else card.reversedId
                    else
                        if (isEnglish) card.uprightEn else card.uprightId,
                    color = if (isDetailReversed) ReversalAmber else LightAntiqueGold
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Love & Relationship Meaning
                DetailSection(
                    title = if (isEnglish) "Love & Relationships" else "Cinta & Hubungan",
                    body = if (isEnglish) card.loveEn else card.loveId,
                    color = MutedViolet
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Self Discovery
                DetailSection(
                    title = if (isEnglish) "Self-Discovery & Wholeness" else "Refleksi Diri & Batin",
                    body = if (isEnglish) card.selfEn else card.selfId,
                    color = CelestialCyan
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Career & Education
                DetailSection(
                    title = if (isEnglish) "Career & Finances" else "Karier & Finansial",
                    body = if (isEnglish) card.careerEn else card.careerId,
                    color = AntiqueGold
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Shadow & Challenge
                DetailSection(
                    title = if (isEnglish) "Shadow Aspect & Challenges" else "Aspek Bayangan & Tantangan",
                    body = if (isEnglish) card.shadowEn else card.shadowId,
                    color = ReversalAmber
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Reflection Question
                DetailSection(
                    title = if (isEnglish) "Journaling Reflection Prompt" else "Pertanyaan Refleksi",
                    body = "\"${if (isEnglish) card.reflectionEn else card.reflectionId}\"",
                    color = LightAntiqueGold
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Visual Symbolism Description
                DetailSection(
                    title = if (isEnglish) "Visual Symbolism" else "Simbolisme Visual",
                    body = if (isEnglish) card.visualDescEn else card.visualDescId,
                    color = MoonSilver
                )

                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}

@Composable
private fun DetailSection(title: String, body: String, color: androidx.compose.ui.graphics.Color) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(0.6.dp, GoldBorderSubtle),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                color = color,
                fontSize = 12.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = body,
                color = MoonSilver,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )
        }
    }
}

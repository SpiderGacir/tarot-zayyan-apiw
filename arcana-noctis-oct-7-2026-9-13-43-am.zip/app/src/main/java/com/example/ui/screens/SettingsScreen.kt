package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ArcanaDatabase
import com.example.data.local.UserPreferences
import com.example.ui.theme.AntiqueGold
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.LightAntiqueGold
import com.example.ui.theme.MoonSilver
import com.example.ui.theme.MutedText
import com.example.ui.theme.Obsidian
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ReversalAmber
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    userPreferences: UserPreferences,
    isEnglish: Boolean,
    allowReversals: Boolean,
    enableHaptics: Boolean,
    reducedMotion: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    var showClearDataDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("settings_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = if (isEnglish) "Settings & Preferences" else "Pengaturan & Preferensi",
            color = LightAntiqueGold,
            fontSize = 22.sp,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = if (isEnglish) "Customize your Arcana Noctis ritual" else "Sesuaikan pengalaman ritual Arcana Noctis",
            color = MoonSilver.copy(alpha = 0.75f),
            fontSize = 11.sp,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Language Option
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = BorderStroke(0.8.dp, GoldBorderSubtle),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Translate, contentDescription = null, tint = AntiqueGold, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (isEnglish) "Language / Bahasa" else "Bahasa Aplikasi",
                        color = LightAntiqueGold,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (!isEnglish) AntiqueGold else ObsidianSurface)
                            .clickable { userPreferences.setLanguage(false) }
                            .padding(vertical = 10.dp)
                            .testTag("set_language_id"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Bahasa Indonesia",
                            color = if (!isEnglish) Obsidian else MoonSilver,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isEnglish) AntiqueGold else ObsidianSurface)
                            .clickable { userPreferences.setLanguage(true) }
                            .padding(vertical = 10.dp)
                            .testTag("set_language_en"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "English",
                            color = if (isEnglish) Obsidian else MoonSilver,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Reading Preferences
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = BorderStroke(0.8.dp, GoldBorderSubtle),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (isEnglish) "Reading Mechanics" else "Mekanisme Pembacaan",
                    color = LightAntiqueGold,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                SettingSwitchItem(
                    title = if (isEnglish) "Allow Reversed Cards" else "Sertakan Kartu Terbalik (Reversed)",
                    desc = if (isEnglish) "Include inverted card orientations for shadow & inner work" else "Memungkinkan kartu muncul dalam orientasi terbalik",
                    checked = allowReversals,
                    onCheckedChange = { userPreferences.setAllowReversals(it) }
                )

                Spacer(modifier = Modifier.height(12.dp))

                SettingSwitchItem(
                    title = if (isEnglish) "Haptic Feedback (Vibration)" else "Umpan Balik Haptik (Getar)",
                    desc = if (isEnglish) "Gentle tactile vibration when drawing and revealing cards" else "Getaran halus saat menarik dan membuka kartu di altar",
                    checked = enableHaptics,
                    onCheckedChange = { userPreferences.setEnableHaptics(it) }
                )

                Spacer(modifier = Modifier.height(12.dp))

                SettingSwitchItem(
                    title = if (isEnglish) "Reduced Motion" else "Kurangi Gerakan Animasi",
                    desc = if (isEnglish) "Simplify floating particles and card transitions" else "Menyederhanakan efek visual mengambang untuk kenyamanan mata",
                    checked = reducedMotion,
                    onCheckedChange = { userPreferences.setReducedMotion(it) }
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Privacy & Local Storage Info
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = BorderStroke(0.8.dp, GoldBorderSubtle),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = AntiqueGold, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isEnglish) "Privacy & Data Storage" else "Privasi & Penyimpanan Data",
                        color = LightAntiqueGold,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (isEnglish)
                        "Your questions, backstories, and journal notes are stored 100% locally on your device via Room SQLite. Nothing is sent to external servers or third-party trackers."
                    else
                        "Pertanyaan, konteks curahan hati, dan catatan jurnalmu disimpan 100% secara lokal di perangkatmu (Room SQLite). Tidak ada data pribadi yang dikirimkan ke server eksternal.",
                    color = MoonSilver,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { showClearDataDialog = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ObsidianSurface,
                        contentColor = ReversalAmber
                    ),
                    border = BorderStroke(0.8.dp, ReversalAmber.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isEnglish) "Clear Local Database" else "Hapus Seluruh Data Lokal",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Version & Creator Info
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "ARCANA NOCTIS v1.0",
                color = MutedText,
                fontSize = 11.sp,
                fontFamily = FontFamily.Serif,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Created by Zayyan Apiw Pradipta",
                color = LightAntiqueGold,
                fontSize = 11.sp
            )
        }

        Spacer(modifier = Modifier.height(50.dp))
    }

    if (showClearDataDialog) {
        AlertDialog(
            onDismissRequest = { showClearDataDialog = false },
            title = {
                Text(
                    text = if (isEnglish) "Clear All Data?" else "Hapus Seluruh Data?",
                    color = ReversalAmber,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = if (isEnglish)
                        "This will permanently delete all saved readings, journal entries, and reset preferences. Continue?"
                    else
                        "Tindakan ini akan menghapus semua riwayat reading dan catatan jurnal dari perangkat ini secara permanen. Lanjutkan?",
                    color = MoonSilver,
                    fontSize = 12.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            val db = ArcanaDatabase.getInstance(context)
                            db.readingDao().clearAll()
                            showClearDataDialog = false
                            Toast.makeText(
                                context,
                                if (isEnglish) "Data cleared." else "Seluruh data lokal berhasil dibersihkan.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ReversalAmber, contentColor = Obsidian)
                ) {
                    Text(if (isEnglish) "Delete All" else "Hapus Semua", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDataDialog = false }) {
                    Text(if (isEnglish) "Cancel" else "Batal", color = MoonSilver)
                }
            },
            containerColor = ObsidianCard
        )
    }
}

@Composable
private fun SettingSwitchItem(
    title: String,
    desc: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = LightAntiqueGold,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                color = MoonSilver.copy(alpha = 0.75f),
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = AntiqueGold,
                checkedTrackColor = DeepViolet,
                uncheckedThumbColor = MoonSilver,
                uncheckedTrackColor = ObsidianSurface
            )
        )
    }
}

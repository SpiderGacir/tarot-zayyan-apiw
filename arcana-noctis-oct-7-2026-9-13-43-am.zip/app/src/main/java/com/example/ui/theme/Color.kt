package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ARCANA NOCTIS Nocturnal Celestial Palette
val MidnightNavy = Color(0xFF090B16)
val Obsidian = Color(0xFF10111C)
val ObsidianSurface = Color(0xFF161826)
val ObsidianCard = Color(0xFF1D1F31)
val ObsidianCardElevated = Color(0xFF26283F)

// Celestial Gold Accents
val AntiqueGold = Color(0xFFD8B777)
val MutedGold = Color(0xFFBA9C5E)
val LightAntiqueGold = Color(0xFFF3E2B8)
val GoldBorder = Color(0xFF6C5A37)
val GoldBorderSubtle = Color(0xFF3D3522)

// Mystic Celestial Tones
val MutedViolet = Color(0xFF8D79BD)
val DeepViolet = Color(0xFF4C3C6B)
val LightViolet = Color(0xFFB7A7DC)
val MoonSilver = Color(0xFFD7D9E8)
val OffWhite = Color(0xFFF4F0E7)
val MutedText = Color(0xFF989AA8)
val DarkBorder = Color(0xFF2B2E45)

// Status & Indicators
val ReversalAmber = Color(0xFFE29A5B)
val CelestialCyan = Color(0xFF72A1BF)

package com.example.ui.screens

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SpreadType
import com.example.data.TarotCard
import com.example.data.TarotRepository
import com.example.ui.components.TarotCardView
import com.example.ui.theme.AntiqueGold
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.LightAntiqueGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MoonSilver
import com.example.ui.theme.MutedGold
import com.example.ui.theme.MutedText
import com.example.ui.theme.Obsidian
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianSurface

@Composable
fun ReadingSessionScreen(
    spread: SpreadType,
    userName: String,
    userQuestion: String,
    userBackstory: String,
    allowReversals: Boolean,
    enableHaptics: Boolean,
    isEnglish: Boolean,
    onCompleteReading: (List<Pair<TarotCard, Boolean>>) -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Pre-draw unique cards from repository
    val drawnPairs = remember {
        TarotRepository.drawCards(
            count = spread.cardCount,
            allowReversals = allowReversals
        )
    }

    // Tracking state of drawn & revealed cards
    val drawnIndices = remember { mutableStateListOf<Int>() }
    val revealedIndices = remember { mutableStateListOf<Int>() }

    fun triggerVibration() {
        if (!enableHaptics) return
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(35)
            }
        } catch (_: Exception) {}
    }

    val isAllDrawn = drawnIndices.size == spread.cardCount
    val isAllRevealed = isAllDrawn && revealedIndices.size == spread.cardCount

    // Pulsing animation for final interpretation button
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_button")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("reading_session_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Altar Header Info
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = BorderStroke(0.8.dp, GoldBorderSubtle),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isEnglish) spread.nameEn else spread.nameId,
                        color = LightAntiqueGold,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${drawnIndices.size}/${spread.cardCount} Kartu",
                        color = MoonSilver,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "\"$userQuestion\"",
                    color = MoonSilver.copy(alpha = 0.9f),
                    fontSize = 12.sp,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Ritual Instructions Banner
        Text(
            text = when {
                !isAllDrawn -> if (isEnglish)
                    "Tap cards from the deck or 'Draw Cards' to place them on your spread."
                else
                    "Ketuk kartu dari dek atau tombol 'Tarik Kartu' untuk menempatkannya di altar."
                !isAllRevealed -> if (isEnglish)
                    "Tap each facedown card to reveal its ancient symbolism."
                else
                    "Ketuk setiap kartu tertutup untuk membuka tabir simbolismenya."
                else -> if (isEnglish)
                    "All cards revealed. Your personalized interpretation is ready."
                else
                    "Seluruh kartu telah terbuka. Interpretasi mendalam siap dibaca."
            },
            color = AntiqueGold,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Spread Layout (Horizontal scrollable cards placed in spread order)
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .testTag("spread_cards_row"),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(horizontal = 10.dp)
        ) {
            items(spread.cardCount) { idx ->
                val isDrawn = drawnIndices.contains(idx)
                val isRevealed = revealedIndices.contains(idx)
                val pair = drawnPairs.getOrNull(idx)
                val position = spread.positions.getOrNull(idx)

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.width(115.dp)
                ) {
                    // Position Title Badge
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(ObsidianSurface)
                            .border(0.6.dp, GoldBorderSubtle, RoundedCornerShape(6.dp))
                            .padding(vertical = 4.dp, horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isEnglish) position?.titleEn ?: "Card ${idx + 1}" else position?.titleId ?: "Kartu ${idx + 1}",
                            color = LightAntiqueGold,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            maxLines = 1
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Card on Altar
                    if (isDrawn && pair != null) {
                        TarotCardView(
                            card = pair.first,
                            isRevealed = isRevealed,
                            isReversed = pair.second,
                            onClick = {
                                if (!isRevealed) {
                                    triggerVibration()
                                    revealedIndices.add(idx)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp),
                            isEnglish = isEnglish,
                            showDetailedBadges = true
                        )
                    } else {
                        // Empty slot awaiting card
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MidnightNavy.copy(alpha = 0.6f))
                                .border(
                                    width = 1.dp,
                                    color = GoldBorder.copy(alpha = 0.35f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable {
                                    if (!isAllDrawn && idx == drawnIndices.size) {
                                        triggerVibration()
                                        drawnIndices.add(idx)
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${idx + 1}",
                                    color = MoonSilver.copy(alpha = 0.4f),
                                    fontSize = 20.sp,
                                    fontFamily = FontFamily.Serif
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (isEnglish) "Slot" else "Kosong",
                                    color = MoonSilver.copy(alpha = 0.3f),
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Interactive Deck Section (when cards are not yet all drawn)
        if (!isAllDrawn) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(0.8.dp, GoldBorderSubtle),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isEnglish) "Sacred Noctis Deck" else "Dek Arcana Noctis",
                        color = LightAntiqueGold,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Simulated Card Fan (Stack)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        for (i in 0 until 5) {
                            Box(
                                modifier = Modifier
                                    .width(60.dp)
                                    .height(90.dp)
                                    .offset(x = (i * -12).dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(ObsidianSurface)
                                    .border(1.dp, GoldBorder, RoundedCornerShape(8.dp))
                                    .clickable {
                                        if (drawnIndices.size < spread.cardCount) {
                                            triggerVibration()
                                            drawnIndices.add(drawnIndices.size)
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = "✦", color = AntiqueGold, fontSize = 16.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                if (drawnIndices.size < spread.cardCount) {
                                    triggerVibration()
                                    drawnIndices.add(drawnIndices.size)
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("draw_single_card_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DeepViolet,
                                contentColor = LightAntiqueGold
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = if (isEnglish) "Draw Next Card" else "Tarik Kartu Berikut",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Button(
                            onClick = {
                                triggerVibration()
                                drawnIndices.clear()
                                for (i in 0 until spread.cardCount) {
                                    drawnIndices.add(i)
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("draw_all_cards_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AntiqueGold,
                                contentColor = Obsidian
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = if (isEnglish) "Draw All Cards" else "Tarik Semua Sekaligus",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        } else if (!isAllRevealed) {
            // All cards drawn, prompt reveal
            Button(
                onClick = {
                    triggerVibration()
                    revealedIndices.clear()
                    for (i in 0 until spread.cardCount) {
                        revealedIndices.add(i)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("reveal_all_cards_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AntiqueGold,
                    contentColor = Obsidian
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isEnglish) "Reveal All Cards" else "Buka Seluruh Kartu",
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Complete Reading CTA (Appears when all revealed)
        AnimatedVisibility(
            visible = isAllRevealed,
            enter = fadeIn() + slideInVertically()
        ) {
            Button(
                onClick = {
                    triggerVibration()
                    onCompleteReading(drawnPairs)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .testTag("view_reading_result_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AntiqueGold.copy(alpha = pulseAlpha),
                    contentColor = Obsidian
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isEnglish) "View Complete Interpretation" else "Baca Hasil Interpretasi Lengkap",
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    letterSpacing = 0.5.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = onCancel,
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(0.6.dp, MoonSilver.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = if (isEnglish) "Cancel Reading" else "Batalkan Reading",
                color = MoonSilver,
                fontSize = 12.sp
            )
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SpreadCategory
import com.example.data.SpreadType
import com.example.data.SpreadsData
import com.example.ui.theme.AntiqueGold
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.LightAntiqueGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MoonSilver
import com.example.ui.theme.MutedText
import com.example.ui.theme.MutedViolet
import com.example.ui.theme.Obsidian
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianSurface

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReadingSelectScreen(
    initialSpreadId: String?,
    isEnglish: Boolean,
    allowReversalsDefault: Boolean,
    onProceedToSession: (
        spread: SpreadType,
        userName: String,
        question: String,
        backstory: String,
        allowReversals: Boolean
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var selectedSpread by remember {
        mutableStateOf(
            SpreadsData.getById(initialSpreadId ?: "three_sca") ?: SpreadsData.threeSituationChallengeAdvice
        )
    }

    var userName by remember { mutableStateOf("") }
    var userQuestion by remember { mutableStateOf("") }
    var userBackstory by remember { mutableStateOf("") }
    var allowReversals by remember { mutableStateOf(allowReversalsDefault) }
    var showCenteringStep by remember { mutableStateOf(false) }

    // Quick suggestion questions
    val suggestionsId = listOf(
        "Bagaimana cara merawat kedamaian hatiku saat ini?",
        "Apa yang belum aku pahami tentang arah karierku?",
        "Dinamika apa yang sesungguhnya terjadi dalam hubungan ini?",
        "Apa akar kegelisahan yang sedang kurasakan?",
        "Langkah bijak apa yang perlu aku ambil berikutnya?"
    )

    val suggestionsEn = listOf(
        "How can I cultivate peace of mind right now?",
        "What am I not seeing regarding my career path?",
        "What is the true underlying dynamic in this relationship?",
        "What is the root of my current inner restlessness?",
        "What is the wisest constructive step forward?"
    )

    val suggestions = if (isEnglish) suggestionsEn else suggestionsId

    // Example backstories
    val exampleBackstoryId = "Saya sedang berada di persimpangan jalan antara mempertahankan kenyamanan posisi saat ini atau mengambil risiko memulai inisiatif baru yang sudah lama saya impikan. Di satu sisi saya merasa siap, tetapi ada keraguan apakah ini waktu yang tepat atau hanya impuls sesaat."
    val exampleBackstoryEn = "I am standing at a crossroads between maintaining the safety of my current circumstances or taking a leap toward a new creative initiative I have dreamed about for years. I feel capable, yet fear of the unknown makes me question my timing."

    if (showCenteringStep) {
        // Centering Contemplation Altar Step
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(MidnightNavy)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(1.2.dp, AntiqueGold)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(DeepViolet.copy(alpha = 0.4f))
                            .border(1.dp, AntiqueGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "☽✦",
                            color = AntiqueGold,
                            fontSize = 24.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Text(
                        text = if (isEnglish) "Quiet the Mind" else "Pusatkan Perhatian Batin",
                        color = LightAntiqueGold,
                        fontSize = 20.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (isEnglish)
                            "Take a slow, deep breath. Anchor your focus on your question:\n\"$userQuestion\"\n\nWhen your heart feels still, begin drawing your cards."
                        else
                            "Tarik napas perlahan dan hembuskan dengan tenang. Pusatkan perhatian pada pertanyaanmu:\n\"$userQuestion\"\n\nKetika hatimu merasa tenang, mulailah menarik kartu.",
                        color = MoonSilver,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            onProceedToSession(
                                selectedSpread,
                                userName,
                                userQuestion,
                                userBackstory,
                                allowReversals
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("confirm_begin_draw_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AntiqueGold,
                            contentColor = Obsidian
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isEnglish) "Draw the Arcana" else "Buka Altar Tarot",
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = { showCenteringStep = false },
                        modifier = Modifier.fillMaxWidth(),
                        border = BorderStroke(0.8.dp, MoonSilver.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (isEnglish) "Back to Edit" else "Kembali Mengedit",
                            color = MoonSilver,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    } else {
        // Main Selection Form
        Column(
            modifier = modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .testTag("reading_select_screen"),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = if (isEnglish) "Prepare Your Reading" else "Persiapkan Tarot Reading",
                color = LightAntiqueGold,
                fontSize = 22.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isEnglish) "Formulate your question with sincerity" else "Pilih format spread dan rumuskan pertanyaanmu",
                color = MoonSilver.copy(alpha = 0.8f),
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            // 1. Spread Selection
            Text(
                text = if (isEnglish) "1. Select Spread" else "1. Pilih Jenis Spread",
                color = AntiqueGold,
                fontSize = 14.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            SpreadsData.allSpreads.forEach { spread ->
                val isSelected = selectedSpread.id == spread.id
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { selectedSpread = spread }
                        .testTag("spread_option_${spread.id}"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) ObsidianCardElevated else ObsidianCard
                    ),
                    border = BorderStroke(
                        width = if (isSelected) 1.5.dp else 0.8.dp,
                        color = if (isSelected) AntiqueGold else GoldBorderSubtle
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) AntiqueGold else ObsidianSurface),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = spread.category.icon,
                                color = if (isSelected) Obsidian else AntiqueGold,
                                fontSize = 14.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isEnglish) spread.nameEn else spread.nameId,
                                    color = LightAntiqueGold,
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Serif,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${spread.cardCount} Kartu",
                                    color = MoonSilver,
                                    fontSize = 10.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (isEnglish) spread.descriptionEn else spread.descriptionId,
                                color = MoonSilver.copy(alpha = 0.75f),
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 2. User Name (Optional)
            Text(
                text = if (isEnglish) "2. Your Name or Initial (Optional)" else "2. Nama Panggilan / Inisial (Opsional)",
                color = AntiqueGold,
                fontSize = 14.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = userName,
                onValueChange = { userName = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("user_name_input"),
                placeholder = {
                    Text(
                        if (isEnglish) "e.g. Maya or M." else "contoh: Maya atau M.",
                        color = MutedText,
                        fontSize = 13.sp
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AntiqueGold,
                    unfocusedBorderColor = GoldBorderSubtle,
                    focusedTextColor = LightAntiqueGold,
                    unfocusedTextColor = LightAntiqueGold
                ),
                shape = RoundedCornerShape(10.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(20.dp))

            // 3. Question Input
            Text(
                text = if (isEnglish) "3. Your Main Question" else "3. Pertanyaan Utama",
                color = AntiqueGold,
                fontSize = 14.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = userQuestion,
                onValueChange = { userQuestion = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("user_question_input"),
                placeholder = {
                    Text(
                        if (isEnglish) "What would you like insight into?" else "Apa yang sedang ingin kamu pahami?",
                        color = MutedText,
                        fontSize = 13.sp
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AntiqueGold,
                    unfocusedBorderColor = GoldBorderSubtle,
                    focusedTextColor = LightAntiqueGold,
                    unfocusedTextColor = LightAntiqueGold
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Quick suggestion chips
            Text(
                text = if (isEnglish) "Quick suggestions:" else "Inspirasi pertanyaan:",
                color = MoonSilver.copy(alpha = 0.7f),
                fontSize = 11.sp,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(6.dp))

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                suggestions.forEach { suggestion ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(ObsidianCard)
                            .border(0.6.dp, GoldBorderSubtle, RoundedCornerShape(16.dp))
                            .clickable { userQuestion = suggestion }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = suggestion,
                            color = MoonSilver,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 4. Backstory / Context with "Use Example"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isEnglish) "4. Backstory / Context" else "4. Latar Belakang / Konteks",
                    color = AntiqueGold,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )

                Row {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(DeepViolet.copy(alpha = 0.35f))
                            .border(0.6.dp, AntiqueGold.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .clickable {
                                userBackstory = if (isEnglish) exampleBackstoryEn else exampleBackstoryId
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("use_example_button")
                    ) {
                        Text(
                            text = if (isEnglish) "Use Example" else "Gunakan Contoh",
                            color = LightAntiqueGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    if (userBackstory.isNotBlank()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(ObsidianSurface)
                                .clickable { userBackstory = "" }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isEnglish) "Clear" else "Hapus",
                                color = MutedText,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            OutlinedTextField(
                value = userBackstory,
                onValueChange = { userBackstory = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .testTag("user_backstory_input"),
                placeholder = {
                    Text(
                        if (isEnglish)
                            "Share more details about your situation to receive a tailored, resonant reflection..."
                        else
                            "Ceritakan lebih banyak tentang situasi yang kamu alami untuk mendapatkan interpretasi yang lebih personal dan relevan...",
                        color = MutedText,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AntiqueGold,
                    unfocusedBorderColor = GoldBorderSubtle,
                    focusedTextColor = LightAntiqueGold,
                    unfocusedTextColor = LightAntiqueGold
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(18.dp))

            // 5. Allow Reversed Cards Toggle
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(0.8.dp, GoldBorderSubtle),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isEnglish) "Include Reversed Cards" else "Sertakan Kartu Terbalik (Reversed)",
                            color = LightAntiqueGold,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isEnglish) "Reversed cards reveal internal resistance, shadow work, or recalibration." else "Kartu terbalik mengungkap refleksi batin, bayangan emosi, dan proses internal.",
                            color = MoonSilver.copy(alpha = 0.7f),
                            fontSize = 10.sp
                        )
                    }
                    Switch(
                        checked = allowReversals,
                        onCheckedChange = { allowReversals = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = AntiqueGold,
                            checkedTrackColor = DeepViolet,
                            uncheckedThumbColor = MoonSilver,
                            uncheckedTrackColor = ObsidianSurface
                        ),
                        modifier = Modifier.testTag("allow_reversals_switch")
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Proceed Button
            Button(
                onClick = {
                    if (userQuestion.isBlank()) {
                        userQuestion = if (isEnglish) "General Guidance & Soul Clarity" else "Refleksi Batin & Arah Hidup"
                    }
                    showCenteringStep = true
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("proceed_to_draw_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AntiqueGold,
                    contentColor = Obsidian
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (isEnglish) "Continue to Sacred Altar" else "Lanjutkan ke Altar Penarikan",
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.SpreadsData
import com.example.data.TarotCard
import com.example.data.TarotRepository
import com.example.ui.components.TarotCardView
import com.example.ui.theme.AntiqueGold
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.LightAntiqueGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MoonSilver
import com.example.ui.theme.MutedGold
import com.example.ui.theme.MutedText
import com.example.ui.theme.MutedViolet
import com.example.ui.theme.Obsidian
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianSurface

@Composable
fun HomeScreen(
    isEnglish: Boolean,
    onStartReading: () -> Unit,
    onSelectSpread: (String) -> Unit,
    onExploreArcana: () -> Unit,
    onCardClick: (TarotCard) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val featuredCards = TarotRepository.getFeaturedCards()

    // Subtle floating animation for hero cards
    val infiniteTransition = rememberInfiniteTransition(label = "hero_float")
    val floatY1 by infiniteTransition.animateFloat(
        initialValue = -6f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "card1"
    )
    val floatY2 by infiniteTransition.animateFloat(
        initialValue = 6f,
        targetValue = -6f,
        animationSpec = infiniteRepeatable(
            animation = tween(3200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "card2"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("home_screen_content"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Hero Section Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp)),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = BorderStroke(1.dp, GoldBorder.copy(alpha = 0.8f))
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                // Altar Background Image
                Image(
                    painter = painterResource(id = R.drawable.hero_moonlit_altar),
                    contentDescription = "Moonlit Altar",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp),
                    contentScale = ContentScale.Crop,
                    alpha = 0.35f
                )

                // Overlay Gradient
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    ObsidianCard.copy(alpha = 0.85f),
                                    ObsidianCard
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Tagline pill
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(ObsidianSurface)
                            .border(0.8.dp, AntiqueGold.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                            .padding(horizontal = 12.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "DISCOVER THE SYMBOLS ✦ UNDERSTAND YOURSELF",
                            color = AntiqueGold,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = if (isEnglish) "Some answers begin within." else "Sebagian jawaban bermula dari dalam diri.",
                        color = LightAntiqueGold,
                        fontSize = 24.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        lineHeight = 30.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (isEnglish)
                            "Find fresh perspectives through sacred symbols, intuition, and timeless stories waiting for you to decipher."
                        else
                            "Temukan perspektif baru melalui simbol, intuisi, dan kisah yang menunggu untuk kamu pahami.",
                        color = MoonSilver.copy(alpha = 0.9f),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Three Floating Cards Preview
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (featuredCards.size >= 3) {
                            TarotCardView(
                                card = featuredCards[0],
                                modifier = Modifier
                                    .width(72.dp)
                                    .offset(y = floatY1.dp),
                                isEnglish = isEnglish,
                                showDetailedBadges = false,
                                onClick = { onCardClick(featuredCards[0]) }
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            TarotCardView(
                                card = featuredCards[1],
                                modifier = Modifier
                                    .width(82.dp)
                                    .offset(y = floatY2.dp),
                                isEnglish = isEnglish,
                                showDetailedBadges = false,
                                onClick = { onCardClick(featuredCards[1]) }
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            TarotCardView(
                                card = featuredCards[2],
                                modifier = Modifier
                                    .width(72.dp)
                                    .offset(y = floatY1.dp),
                                isEnglish = isEnglish,
                                showDetailedBadges = false,
                                onClick = { onCardClick(featuredCards[2]) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // CTA Buttons
                    Button(
                        onClick = onStartReading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("begin_reading_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AntiqueGold,
                            contentColor = Obsidian
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isEnglish) "Begin Your Reading" else "Mulai Tarot Reading",
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            letterSpacing = 1.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = onExploreArcana,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("explore_arcana_button"),
                        border = BorderStroke(1.dp, AntiqueGold.copy(alpha = 0.7f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = LightAntiqueGold),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (isEnglish) "Explore the 78 Arcana" else "Jelajahi 78 Kartu Arcana",
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Choose Your Path Section
        SectionHeader(
            title = if (isEnglish) "Choose Your Path" else "Pilih Jalur Pertanyaanmu",
            subtitle = if (isEnglish) "Targeted spreads for different crossroads in your life" else "Berbagai spread terarah untuk setiap persimpangan hidupmu"
        )

        Spacer(modifier = Modifier.height(14.dp))

        PathCard(
            title = if (isEnglish) "Love & Relationships" else "Cinta & Hubungan",
            desc = if (isEnglish) "5-card spread examining personal needs, mutual dynamics & healthy steps." else "Spread 5 kartu untuk dinamika hubungan, kebutuhan diri & langkah sehat.",
            icon = Icons.Default.Favorite,
            badge = "5 Cards",
            onClick = { onSelectSpread("love_5") }
        )

        Spacer(modifier = Modifier.height(10.dp))

        PathCard(
            title = if (isEnglish) "The Unfinished Connection" else "The Unfinished Connection",
            desc = if (isEnglish) "10-card exploration for ambiguous connections, closure & inner release." else "10 kartu untuk hubungan tanpa kepastian, akar keterikatan & kejelasan batin.",
            icon = Icons.Default.AutoAwesome,
            badge = "10 Cards",
            onClick = { onSelectSpread("unfinished_10") }
        )

        Spacer(modifier = Modifier.height(10.dp))

        PathCard(
            title = if (isEnglish) "Self-Discovery & Wholeness" else "Pencarian Jati Diri & Batin",
            desc = if (isEnglish) "Explore latent strengths, subconscious patterns, and daily actions." else "Menyelami kekuatan terpendam, pola bawah sadar, dan pemulihan jiwa.",
            icon = Icons.Default.Psychology,
            badge = "5 Cards",
            onClick = { onSelectSpread("self_5") }
        )

        Spacer(modifier = Modifier.height(10.dp))

        PathCard(
            title = if (isEnglish) "Career & Financial Direction" else "Karier, Pendidikan & Finansial",
            desc = if (isEnglish) "Strategic layout analyzing real obstacles, assets, and next concrete moves." else "Analisis hambatan nyata, kekuatan utama, dan langkah profesional terukur.",
            icon = Icons.Default.Work,
            badge = "5 Cards",
            onClick = { onSelectSpread("career_5") }
        )

        Spacer(modifier = Modifier.height(10.dp))

        PathCard(
            title = if (isEnglish) "One Card & Three-Card Spreads" else "Refleksi Harian & 3 Kartu",
            desc = if (isEnglish) "Concise daily insight or Past-Present-Future timeline spreads." else "Satu kartu harian atau garis waktu Masa Lalu - Sekarang - Masa Depan.",
            icon = Icons.Default.Search,
            badge = "1 - 3 Cards",
            onClick = { onSelectSpread("three_sca") }
        )

        Spacer(modifier = Modifier.height(28.dp))

        // How Tarot Works Section
        SectionHeader(
            title = if (isEnglish) "How Tarot Works" else "Bagaimana Tarot Bekerja",
            subtitle = if (isEnglish) "A modern, grounded approach to ancient symbolic art" else "Pendekatan modern dan membumi terhadap seni simbolik kuno"
        )

        Spacer(modifier = Modifier.height(14.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = ObsidianCard),
            border = BorderStroke(0.8.dp, GoldBorderSubtle),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                StepItem(
                    number = "1",
                    title = if (isEnglish) "Mindful Card Selection" else "Pemilihan Kartu Secara Sadar",
                    body = if (isEnglish)
                        "Tarik kartu dengan pikiran terpusat. Kartu yang terpilih merefleksikan alam bawah sadar dan kondisi energimu saat ini."
                    else
                        "Tarik kartu dengan pikiran terpusat. Kartu yang terpilih merefleksikan alam bawah sadar dan kondisi energimu saat ini."
                )
                Spacer(modifier = Modifier.height(14.dp))
                StepItem(
                    number = "2",
                    title = if (isEnglish) "Symbolic Interpretation" else "Interpretasi Simbolik yang Dalam",
                    body = if (isEnglish)
                        "Setiap kartu mengandung arketipe psikologis kaya yang membuka sudut pandang baru atas persoalanmu."
                    else
                        "Setiap kartu mengandung arketipe psikologis kaya yang membuka sudut pandang baru atas persoalanmu."
                )
                Spacer(modifier = Modifier.height(14.dp))
                StepItem(
                    number = "3",
                    title = if (isEnglish) "Grounded Self-Reflection" else "Refleksi & Aksi Nyata",
                    body = if (isEnglish)
                        "Tarot bukan vonis takdir mutlak. Gunakan wawasan ini untuk mengambil keputusan hidup yang berdaulat dan matang."
                    else
                        "Tarot bukan vonis takdir mutlak. Gunakan wawasan ini untuk mengambil keputusan hidup yang berdaulat dan matang."
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Explore the 78 Arcana Section
        SectionHeader(
            title = if (isEnglish) "The Complete 78 Arcana" else "Katalog Lengkap 78 Arcana",
            subtitle = if (isEnglish) "22 Major Arcana and 56 Minor Arcana with deep dual meanings" else "22 Major Arcana & 56 Minor Arcana dengan makna tegak dan terbalik"
        )

        Spacer(modifier = Modifier.height(14.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onExploreArcana() },
            colors = CardDefaults.cardColors(containerColor = ObsidianCardElevated),
            border = BorderStroke(1.dp, AntiqueGold.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isEnglish) "Explore Card Encyclopedia" else "Buka Ensiklopedia Tarot",
                        color = LightAntiqueGold,
                        fontSize = 15.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isEnglish) "Search by keywords, suits (Wands, Cups, Swords, Pentacles) and inspect symbols." else "Cari berdasarkan kata kunci, elemen (Api, Air, Udara, Tanah) & simbolisme visual.",
                        color = MoonSilver.copy(alpha = 0.8f),
                        fontSize = 12.sp
                    )
                }
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = AntiqueGold,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Demo User Reflections
        SectionHeader(
            title = if (isEnglish) "Example Reflections (Demo)" else "Contoh Refleksi Pengguna (Demo)",
            subtitle = if (isEnglish) "Sample experiences exploring self-awareness with Arcana Noctis" else "Simulasi pengalaman menemukan kejelasan melalui Arcana Noctis"
        )

        Spacer(modifier = Modifier.height(14.dp))

        DemoTestimonialCard(
            author = "Nadia, 27 (Contoh Demo)",
            title = if (isEnglish) "Love Reading: Letting Go of Ambiguity" else "Love Reading: Melepaskan Hubungan Tanpa Kepastian",
            content = if (isEnglish)
                "\"The Unfinished Connection spread helped me realize that the closure I was desperately seeking from someone else actually had to come from within myself.\""
            else
                "\"Spread The Unfinished Connection membantuku menyadari bahwa kepastian yang selama ini aku cari dari orang lain ternyata harus dimulai dari keberanian menetapkan batasan diri sendiri.\""
        )

        Spacer(modifier = Modifier.height(10.dp))

        DemoTestimonialCard(
            author = "Dimas, 31 (Contoh Demo)",
            title = if (isEnglish) "Career Spread: Stepping Into Leadership" else "Career Spread: Keberanian Mengambil Keputusan",
            content = if (isEnglish)
                "\"Three-Card spread gave me the courage to stop second-guessing my expertise and launch the creative studio I had dreamed of for years.\""
            else
                "\"Spread Tiga Kartu memberi perspektif jernih untuk berhenti meragukan keahlianku sendiri dan berani memimpin proyek baru dengan integritas.\""
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Footer Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "ARCANA NOCTIS",
                color = AntiqueGold,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Designed & Created by Zayyan Apiw Pradipta",
                color = LightAntiqueGold,
                fontSize = 11.sp,
                fontFamily = FontFamily.Serif
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (isEnglish)
                    "Independent digital experience exploring tarot symbolism and personal reflection."
                else
                    "Pengalaman digital independen yang mengeksplorasi simbolisme tarot dan refleksi diri.",
                color = MutedText,
                fontSize = 10.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (isEnglish)
                    "Tarot is a reflective tool. Not a deterministic prediction."
                else
                    "Tarot adalah sarana refleksi batin, bukan kepastian ramalan masa depan.",
                color = MutedText.copy(alpha = 0.7f),
                fontSize = 9.sp,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

@Composable
private fun SectionHeader(title: String, subtitle: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = title,
            color = LightAntiqueGold,
            fontSize = 18.sp,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = subtitle,
            color = MoonSilver.copy(alpha = 0.75f),
            fontSize = 12.sp
        )
    }
}

@Composable
private fun PathCard(
    title: String,
    desc: String,
    icon: ImageVector,
    badge: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(0.8.dp, GoldBorder.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(DeepViolet.copy(alpha = 0.35f))
                    .border(0.8.dp, AntiqueGold.copy(alpha = 0.6f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = AntiqueGold,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        color = LightAntiqueGold,
                        fontSize = 14.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(ObsidianSurface)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = badge,
                            color = MoonSilver,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = desc,
                    color = MoonSilver.copy(alpha = 0.8f),
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

@Composable
private fun StepItem(number: String, title: String, body: String) {
    Row(verticalAlignment = Alignment.Top) {
        Box(
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(AntiqueGold.copy(alpha = 0.2f))
                .border(1.dp, AntiqueGold, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                color = LightAntiqueGold,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = title,
                color = LightAntiqueGold,
                fontSize = 13.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = body,
                color = MoonSilver.copy(alpha = 0.8f),
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }
    }
}

@Composable
private fun DemoTestimonialCard(author: String, title: String, content: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(0.6.dp, GoldBorderSubtle),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    color = LightAntiqueGold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = author,
                    color = MutedText,
                    fontSize = 10.sp
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = content,
                color = MoonSilver.copy(alpha = 0.85f),
                fontSize = 11.sp,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                lineHeight = 16.sp
            )
        }
    }
}

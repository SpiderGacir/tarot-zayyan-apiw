package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TarotRepository
import com.example.data.local.ArcanaDatabase
import com.example.data.local.ReadingDao
import com.example.data.local.ReadingEntity
import com.example.ui.theme.AntiqueGold
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.LightAntiqueGold
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.MoonSilver
import com.example.ui.theme.MutedText
import com.example.ui.theme.Obsidian
import com.example.ui.theme.ObsidianCard
import com.example.ui.theme.ObsidianCardElevated
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ReversalAmber
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JournalScreen(
    isEnglish: Boolean,
    onStartReading: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dao = remember { ArcanaDatabase.getInstance(context).readingDao() }

    var searchQuery by remember { mutableStateOf("") }
    var filterFavoritesOnly by remember { mutableStateOf(false) }

    val allReadings by (if (filterFavoritesOnly) dao.getFavoritesFlow() else dao.getAllFlow())
        .collectAsState(initial = emptyList())

    val displayList = remember(allReadings, searchQuery) {
        if (searchQuery.isBlank()) allReadings
        else allReadings.filter {
            it.customTitle.contains(searchQuery, ignoreCase = true) ||
            it.question.contains(searchQuery, ignoreCase = true) ||
            it.spreadName.contains(searchQuery, ignoreCase = true) ||
            it.personalNotes.contains(searchQuery, ignoreCase = true)
        }
    }

    var selectedReadingForDetail by remember { mutableStateOf<ReadingEntity?>(null) }
    var showDeleteSingleDialog by remember { mutableStateOf<ReadingEntity?>(null) }
    var showClearAllDialog by remember { mutableStateOf(false) }

    fun exportAllToText() {
        if (allReadings.isEmpty()) return
        val text = buildString {
            appendLine("=== ARCANA NOCTIS TAROT JOURNAL ===")
            appendLine("Designed & Created by Zayyan Apiw Pradipta")
            appendLine("Total Entries: ${allReadings.size}")
            appendLine()
            allReadings.forEachIndexed { i, r ->
                appendLine("[$i] ${r.customTitle} (${r.formattedDate})")
                appendLine("Spread: ${r.spreadName}")
                appendLine("Pertanyaan: ${r.question}")
                appendLine("Ringkasan: ${r.executiveSummary}")
                if (r.personalNotes.isNotBlank()) {
                    appendLine("Catatan Pribadi: ${r.personalNotes}")
                }
                appendLine("-".repeat(30))
                appendLine()
            }
        }
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, text)
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, if (isEnglish) "Export Journal" else "Ekspor Jurnal")
        context.startActivity(shareIntent)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("journal_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (isEnglish) "Tarot Journal" else "Jurnal & Riwayat Reading",
                    color = LightAntiqueGold,
                    fontSize = 20.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isEnglish) "${allReadings.size} saved reflections" else "${allReadings.size} reading tersimpan",
                    color = MoonSilver.copy(alpha = 0.7f),
                    fontSize = 11.sp
                )
            }

            Row {
                if (allReadings.isNotEmpty()) {
                    IconButton(
                        onClick = { exportAllToText() },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(ObsidianCard)
                            .size(36.dp)
                            .testTag("export_journal_button")
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = "Export", tint = AntiqueGold, modifier = Modifier.size(18.dp))
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = { showClearAllDialog = true },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(ObsidianCard)
                            .size(36.dp)
                            .testTag("clear_all_journal_button")
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Clear All", tint = ReversalAmber, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search & Favorites Filter
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .weight(1f)
                    .testTag("journal_search_input"),
                placeholder = {
                    Text(
                        text = if (isEnglish) "Search journal..." else "Cari judul, pertanyaan, catatan...",
                        color = MutedText,
                        fontSize = 12.sp
                    )
                },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = AntiqueGold, modifier = Modifier.size(18.dp))
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = MoonSilver, modifier = Modifier.size(16.dp))
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AntiqueGold,
                    unfocusedBorderColor = GoldBorderSubtle,
                    focusedTextColor = LightAntiqueGold,
                    unfocusedTextColor = LightAntiqueGold
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Favorites Filter Toggle
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (filterFavoritesOnly) AntiqueGold else ObsidianCard)
                    .border(0.8.dp, GoldBorderSubtle, RoundedCornerShape(12.dp))
                    .clickable { filterFavoritesOnly = !filterFavoritesOnly }
                    .padding(10.dp)
                    .testTag("filter_favorites_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (filterFavoritesOnly) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Favorites",
                    tint = if (filterFavoritesOnly) Obsidian else AntiqueGold,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Readings List or Empty State
        if (displayList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(20.dp)
                ) {
                    Text(text = "☾✦☽", color = AntiqueGold, fontSize = 28.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (allReadings.isEmpty())
                            if (isEnglish) "Your journal is waiting." else "Jurnal batinmu masih kosong."
                        else
                            if (isEnglish) "No readings match your search." else "Tidak ada reading yang cocok dengan pencarian.",
                        color = LightAntiqueGold,
                        fontSize = 16.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (allReadings.isEmpty())
                            if (isEnglish)
                                "Begin your first reading to record insights, reflect on symbols, and cultivate self-awareness."
                            else
                                "Mulai tarot reading pertamamu untuk mencatat refleksi, memahami simbol, dan merawat kesadaran diri."
                        else
                            if (isEnglish) "Try clearing search or filter." else "Coba ubah kata kunci atau nonaktifkan filter favorit.",
                        color = MoonSilver.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(18.dp))
                    if (allReadings.isEmpty()) {
                        Button(
                            onClick = onStartReading,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AntiqueGold,
                                contentColor = Obsidian
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("journal_start_reading_button")
                        ) {
                            Text(
                                text = if (isEnglish) "Begin Reading" else "Mulai Reading Pertama",
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("journal_readings_list"),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(displayList, key = { it.id }) { reading ->
                    JournalItemCard(
                        reading = reading,
                        isEnglish = isEnglish,
                        onOpen = { selectedReadingForDetail = reading },
                        onToggleFavorite = {
                            coroutineScope.launch {
                                dao.update(reading.copy(isFavorite = !reading.isFavorite))
                            }
                        },
                        onDelete = { showDeleteSingleDialog = reading }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(60.dp))
                }
            }
        }
    }

    // Modal Sheet for Reading Detail & Edit Notes
    if (selectedReadingForDetail != null) {
        val reading = selectedReadingForDetail!!
        var editedTitle by remember(reading) { mutableStateOf(reading.customTitle) }
        var editedNotes by remember(reading) { mutableStateOf(reading.personalNotes) }
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
        val modalScrollState = rememberScrollState()

        ModalBottomSheet(
            onDismissRequest = { selectedReadingForDetail = null },
            sheetState = sheetState,
            containerColor = ObsidianCard
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(modalScrollState)
                    .padding(horizontal = 20.dp, vertical = 10.dp)
                    .testTag("journal_detail_modal")
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = reading.spreadName,
                        color = AntiqueGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = { selectedReadingForDetail = null }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = MoonSilver)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Editable Title
                OutlinedTextField(
                    value = editedTitle,
                    onValueChange = { editedTitle = it },
                    label = { Text(if (isEnglish) "Reading Title" else "Judul Reading", color = MoonSilver) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_reading_title_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AntiqueGold,
                        unfocusedBorderColor = GoldBorderSubtle,
                        focusedTextColor = LightAntiqueGold,
                        unfocusedTextColor = LightAntiqueGold
                    ),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "${reading.formattedDate} • ${reading.userName}",
                    color = MoonSilver.copy(alpha = 0.7f),
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Question & Summary
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (isEnglish) "Question:" else "Pertanyaan:",
                            color = AntiqueGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "\"${reading.question}\"",
                            color = LightAntiqueGold,
                            fontSize = 13.sp,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isEnglish) "Summary:" else "Ringkasan:",
                            color = AntiqueGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = reading.executiveSummary,
                            color = MoonSilver,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Card IDs preview
                val cardIdList = reading.cardIds.split(",").filter { it.isNotBlank() }
                val revList = reading.cardReversals.split(",").map { it.toBooleanStrictOrNull() ?: false }

                Text(
                    text = if (isEnglish) "Cards Drawn:" else "Kartu yang Terpilih:",
                    color = AntiqueGold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                cardIdList.forEachIndexed { i, cId ->
                    val card = TarotRepository.getCardById(cId)
                    val isRev = revList.getOrNull(i) ?: false
                    if (card != null) {
                        Text(
                            text = "• ${if (isEnglish) card.nameEn else card.nameId} ${if (isRev) "(Reversed)" else "(Upright)"}",
                            color = MoonSilver,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Editable Personal Notes
                OutlinedTextField(
                    value = editedNotes,
                    onValueChange = { editedNotes = it },
                    label = { Text(if (isEnglish) "Personal Journal Notes" else "Catatan Pribadi & Refleksi", color = MoonSilver) },
                    placeholder = {
                        Text(
                            if (isEnglish) "What did you realize days after this reading?" else "Apa yang kamu sadari setelah merenungkan reading ini?",
                            color = MutedText,
                            fontSize = 12.sp
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .testTag("edit_personal_notes_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AntiqueGold,
                        unfocusedBorderColor = GoldBorderSubtle,
                        focusedTextColor = LightAntiqueGold,
                        unfocusedTextColor = LightAntiqueGold
                    ),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Save Changes Button
                Button(
                    onClick = {
                        coroutineScope.launch {
                            dao.update(
                                reading.copy(
                                    customTitle = editedTitle.ifBlank { reading.customTitle },
                                    personalNotes = editedNotes
                                )
                            )
                            selectedReadingForDetail = null
                            Toast.makeText(
                                context,
                                if (isEnglish) "Journal updated!" else "Jurnal diperbarui!",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("save_journal_edits_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AntiqueGold,
                        contentColor = Obsidian
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = if (isEnglish) "Save Changes" else "Simpan Perubahan",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }

    // Confirmation dialog for deleting single reading
    if (showDeleteSingleDialog != null) {
        val readingToDelete = showDeleteSingleDialog!!
        AlertDialog(
            onDismissRequest = { showDeleteSingleDialog = null },
            title = {
                Text(
                    text = if (isEnglish) "Delete Reading?" else "Hapus Reading?",
                    color = LightAntiqueGold,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = if (isEnglish)
                        "Are you sure you want to delete '${readingToDelete.customTitle}' from your journal? This cannot be undone."
                    else
                        "Apakah kamu yakin ingin menghapus '${readingToDelete.customTitle}' dari jurnal? Tindakan ini tidak dapat dibatalkan.",
                    color = MoonSilver,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            dao.delete(readingToDelete)
                            showDeleteSingleDialog = null
                            Toast.makeText(
                                context,
                                if (isEnglish) "Deleted." else "Reading dihapus.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ReversalAmber, contentColor = Obsidian)
                ) {
                    Text(if (isEnglish) "Delete" else "Hapus", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteSingleDialog = null }) {
                    Text(if (isEnglish) "Cancel" else "Batal", color = MoonSilver)
                }
            },
            containerColor = ObsidianCard
        )
    }

    // Confirmation dialog for clearing all journal
    if (showClearAllDialog) {
        AlertDialog(
            onDismissRequest = { showClearAllDialog = false },
            title = {
                Text(
                    text = if (isEnglish) "Clear Entire Journal?" else "Hapus Seluruh Riwayat?",
                    color = ReversalAmber,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = if (isEnglish)
                        "All saved readings will be permanently removed from this device. Are you sure?"
                    else
                        "Seluruh riwayat reading yang tersimpan di perangkat ini akan dihapus secara permanen. Lanjutkan?",
                    color = MoonSilver,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            dao.clearAll()
                            showClearAllDialog = false
                            Toast.makeText(
                                context,
                                if (isEnglish) "All entries cleared." else "Seluruh riwayat dihapus.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ReversalAmber, contentColor = Obsidian)
                ) {
                    Text(if (isEnglish) "Clear All" else "Hapus Semua", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearAllDialog = false }) {
                    Text(if (isEnglish) "Cancel" else "Batal", color = MoonSilver)
                }
            },
            containerColor = ObsidianCard
        )
    }
}

@Composable
private fun JournalItemCard(
    reading: ReadingEntity,
    isEnglish: Boolean,
    onOpen: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpen() }
            .testTag("journal_item_${reading.id}"),
        colors = CardDefaults.cardColors(containerColor = ObsidianCard),
        border = BorderStroke(0.8.dp, GoldBorderSubtle),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(ObsidianSurface)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = reading.spreadName,
                        color = AntiqueGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = if (reading.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = if (reading.isFavorite) AntiqueGold else MutedText,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = MutedText,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = reading.customTitle,
                color = LightAntiqueGold,
                fontSize = 14.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = "\"${reading.question}\"",
                color = MoonSilver.copy(alpha = 0.85f),
                fontSize = 11.sp,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = reading.executiveSummary,
                color = MoonSilver.copy(alpha = 0.7f),
                fontSize = 11.sp,
                lineHeight = 15.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = reading.formattedDate,
                    color = MutedText,
                    fontSize = 10.sp
                )
                if (reading.personalNotes.isNotBlank()) {
                    Text(
                        text = "✎ Catatan ada",
                        color = AntiqueGold,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}
